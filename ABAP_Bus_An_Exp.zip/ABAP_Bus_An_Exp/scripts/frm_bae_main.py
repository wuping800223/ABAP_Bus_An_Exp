#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ABAP Business Analysis & Explanation Tool - Main Entry Point
ABAP代码业务逻辑分析和注释工具 - 主入口

Author: 吴平
联系方式: 13574840501 | 微信号：wuping800223
Date: 2026-04-22
Version: 1.0.0
"""

import sys
import os

# Windows UTF-8 模式
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# 添加脚本目录到路径
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from pathlib import Path
from datetime import datetime
import json

# 导入各模块
from frm_bae_file_handler import FileHandler, ABAPFile
from frm_bae_analyzer import ABAPBusinessAnalyzer, AnalysisReport
from frm_bae_report_generator import ReportGenerator
from frm_bae_pdf_builder import AnalysisPDFGenerator


class ABAPBusAnExpTool:
    """ABAP业务逻辑分析和注释工具主类"""

    def __init__(self):
        """初始化工具"""
        self.file_handler = FileHandler()
        self.analyzer = ABAPBusinessAnalyzer()
        self.report_generator = ReportGenerator()
        self.pdf_generator = AnalysisPDFGenerator(silent=True)
        self.user_hints = []  # 用户提供的提示信息

        # 输出目录：优先工作区 ABAP_AnExp_Reports，否则用户主目录
        # 用户可在分析时通过 --output-dir 或交互方式自行指定其他目录
        self.output_dir = self._resolve_default_output_dir()

    def _resolve_default_output_dir(self):
        """解析默认输出目录

        查找优先级：
        1. 当前工作目录下的 ABAP_AnExp_Reports
        2. 向上最多查找 4 级父目录
        3. 用户主目录下的 ABAP_AnExp_Reports
        """
        candidates = []
        search = Path(os.getcwd())
        for _ in range(5):
            candidates.append(search / 'ABAP_AnExp_Reports')
            search = search.parent
        candidates.append(Path.home() / 'ABAP_AnExp_Reports')

        for c in candidates:
            try:
                c.mkdir(parents=True, exist_ok=True)
                return c
            except Exception:
                continue

        fallback = Path.home() / 'ABAP_AnExp_Reports'
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback

    def _check_pdf_available(self) -> bool:
        """检查PDF生成库是否可用"""
        try:
            import reportlab
            return True
        except ImportError:
            return False

    def _install_pdf_library(self) -> bool:
        """安装PDF生成库"""
        print("\n📦 正在安装 PDF 生成库 (reportlab)...")
        try:
            import subprocess
            result = subprocess.run(['pip', 'install', 'reportlab'],
                                    capture_output=True, text=True, timeout=120)
            if result.returncode == 0:
                print("✅ reportlab 安装成功！")
                return True
            else:
                print(f"⚠️ 安装失败: {result.stderr}")
                return False
        except Exception as e:
            print(f"⚠️ 安装出错: {e}")
            return False

    def prompt_user_hints(self, hints: str = None):
        """收集用户提供的提示信息

        用户可在分析时输入自己对程序的了解（如业务背景、已知问题等），
        这些信息会融入业务逻辑分析，并在报告中标注为「用户提供」。

        Args:
            hints: 可选，直接传入提示文本（命令行参数模式）
        """
        if hints is not None:
            if hints.strip():
                self.user_hints = [h.strip() for h in hints.split(',') if h.strip()]
            return

        # 交互式模式
        print("\n" + "=" * 60)
        print("提示（可选）：如果您了解此程序的业务背景、")
        print("  已知问题或其他情况，请输入以增强分析效果。")
        print("  多条提示用逗号分隔，直接回车跳过。")
        print("=" * 60)
        try:
            user_input = input("提示：").strip()
            if user_input:
                self.user_hints = [h.strip() for h in user_input.split(',') if h.strip()]
                print(f"  已接收 {len(self.user_hints)} 条提示")
        except (EOFError, IOError):
            pass

    def prompt_save_format(self, choice: str = None) -> str:
        """提示用户选择保存格式

        Args:
            choice: 可选，指定格式（命令行参数自动化）

        Returns:
            str: 选择的格式 ['text', 'html', 'json', 'pdf', 'all']
        """
        format_map = {
            '1': ('text', 'TXT'),
            '2': ('html', 'HTML'),
            '3': ('json', 'JSON'),
            '4': ('pdf', 'PDF'),
            '5': ('all', '所有格式'),
        }
        default_choice = '2'

        # 命令行参数自动化模式
        if choice is not None:
            name_to_num = {'text': '1', 'html': '2', 'json': '3', 'pdf': '4', 'all': '5'}
            if choice.lower() in name_to_num:
                choice = name_to_num[choice.lower()]
            if choice in format_map:
                selected_fmt, fmt_name = format_map[choice]
                print(f"\n💾 已选择格式: {fmt_name}")
                if selected_fmt in ('pdf', 'all'):
                    if not self._check_pdf_available():
                        if not self._install_pdf_library():
                            print("⚠️ PDF库安装失败，降级为HTML格式")
                            return 'html'
                return selected_fmt
            else:
                print(f"⚠️ 无效格式 '{choice}'，使用默认HTML")
                return 'html'

        # 交互式模式
        print("\n" + "=" * 60)
        print("💾 分析报告已生成！请选择保存格式：")
        print("=" * 60)
        print("  1. TXT  - 纯文本格式，代码与注释交织显示")
        print("  2. HTML - 网页格式，样式美观（⭐推荐）")
        print("  3. JSON - JSON格式，适合程序处理")
        print("  4. PDF  - PDF文档，适合打印存档")
        print("  5. ALL  - 保存所有格式\n")

        try:
            while True:
                user_input = input(f"请输入选项 [1-5] (默认{default_choice}): ").strip()
                if user_input == '':
                    user_input = default_choice
                if user_input not in format_map:
                    print("❌ 无效选择，请输入 1-5")
                    continue
                selected_fmt, _ = format_map[user_input]
                if selected_fmt in ('pdf', 'all'):
                    if not self._check_pdf_available():
                        if not self._install_pdf_library():
                            print("⚠️ PDF库安装失败，已移除PDF相关选项")
                            del format_map['4']
                            del format_map['5']
                            if user_input not in format_map:
                                print("📋 请重新选择其他格式")
                                continue
                return selected_fmt
        except (EOFError, IOError):
            print("📋 自动选择: HTML（推荐）")
            return 'html'

    def analyze_file(self, file_path: str) -> AnalysisReport:
        """分析文件或目录

        Args:
            file_path: 文件或目录路径

        Returns:
            AnalysisReport: 分析报告
        """
        from pathlib import Path

        abap_files = self.file_handler.process_file(file_path)

        if not abap_files:
            raise ValueError(f"未找到ABAP文件: {file_path}")

        is_directory = len(abap_files) > 1 or Path(file_path).is_dir()

        if is_directory:
            # 目录模式：识别主程序 -> 解析INCLUDE顺序 -> 按序分析每个文件
            print(f"  📁 目录模式：发现 {len(abap_files)} 个文件")
            return self.analyzer.analyze_directory(
                abap_files, str(Path(file_path).resolve()), user_hints=self.user_hints
            )
        else:
            abap_file = abap_files[0]
            return self.analyzer.analyze(abap_file, user_hints=self.user_hints)

    def analyze_snippet(self, code: str, name: str = "snippet") -> AnalysisReport:
        """分析代码片段

        Args:
            code: ABAP代码片段
            name: 名称

        Returns:
            AnalysisReport: 分析报告
        """
        abap_files = self.file_handler.process_snippet(code, name)
        if not abap_files:
            raise ValueError("代码片段为空")
        return self.analyzer.analyze(abap_files[0], user_hints=self.user_hints)

    def save_report_interactive(self, report: AnalysisReport, choice: str = None) -> list:
        """交互式保存报告

        Args:
            report: 分析报告
            choice: 可选，指定格式（命令行参数）

        Returns:
            list: 生成的报告文件路径列表
        """
        base_name = Path(report.file_name).stem

        ts_suffix = datetime.now().strftime("_%Y%m%d_%H%M%S")

        base_name = f"{base_name}{ts_suffix}"

        fmt = self.prompt_save_format(choice)

        output_formats = ['text', 'html', 'json', 'pdf'] if fmt == 'all' else [fmt]

        generated_files = []
        for f in output_formats:
            if f == 'text':
                path = self.output_dir / f"{base_name}_analysis.txt"
                self.report_generator.generate_text(report, str(path))
                generated_files.append(str(path))
                print(f"  ✅ 已保存: {path}")
            elif f == 'html':
                path = self.output_dir / f"{base_name}_analysis.html"
                self.report_generator.generate_html(report, str(path))
                generated_files.append(str(path))
                print(f"  ✅ 已保存: {path}")
            elif f == 'json':
                path = self.output_dir / f"{base_name}_analysis.json"
                self.report_generator.generate_json(report, str(path))
                generated_files.append(str(path))
                print(f"  ✅ 已保存: {path}")
            elif f == 'pdf':
                html_path = self.output_dir / f"{base_name}_analysis.html"
                self.report_generator.generate_html(report, str(html_path))
                pdf_path = self.output_dir / f"{base_name}_analysis.pdf"
                self.pdf_generator.generate_from_html(str(html_path), str(pdf_path))
                generated_files.append(str(pdf_path))
                print(f"  ✅ 已保存: {pdf_path}")

        return generated_files


def main():
    """命令行入口"""
    import argparse

    parser = argparse.ArgumentParser(
        description='ABAP代码业务逻辑分析和注释工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 交互式分析文件（推荐）
  python bae_main.py --file test.abap

  # 分析文件并指定输出格式
  python bae_main.py --file test.abap --output html

  # 分析代码片段
  python bae_main.py --snippet "SELECT * FROM mara."

  # 分析ZIP包
  python bae_main.py --file archive.zip --output all

  # 指定输出目录
  python bae_main.py --file test.abap --output-dir D:/output
        """
    )

    parser.add_argument('--file', '-f', help='ABAP文件路径')
    parser.add_argument('--snippet', '-s', help='ABAP代码片段')
    parser.add_argument('--name', '-n', default='snippet', help='代码片段名称')
    parser.add_argument('--output', '-o', choices=['text', 'html', 'json', 'pdf', 'all'],
                        help='输出格式（不指定则交互式选择）')
    parser.add_argument('--output-dir', help='输出目录')
    parser.add_argument('--hints', help='用户提示信息（多条用逗号分隔，用于增强业务逻辑分析）')

    args = parser.parse_args()

    if not args.file and not args.snippet:
        parser.print_help()
        return

    tool = ABAPBusAnExpTool()

    # 收集用户提示
    tool.prompt_user_hints(getattr(args, 'hints', None))

    if args.output_dir:
        tool.output_dir = Path(args.output_dir)
        tool.output_dir.mkdir(parents=True, exist_ok=True)

    try:
        if args.file:
            print(f"\n🔍 正在分析文件: {args.file}")
            report = tool.analyze_file(args.file)
        else:
            print(f"\n🔍 正在分析代码片段...")
            report = tool.analyze_snippet(args.snippet, args.name)

        print("\n" + "=" * 60)
        print("📊 分析完成！")
        print("=" * 60)
        print(f"   文件名称: {report.file_name}")
        print(f"   代码行数: {report.total_lines}")
        print(f"   注释条目: {len(report.annotations)}")
        print(f"   代码来源: {report.source_type}")

        print("\n" + "-" * 60)
        print("📝 整体业务逻辑摘要:")
        for line in report.overall_logic.split('\n')[:6]:
            print(f"   {line}")

        files = tool.save_report_interactive(report, choice=args.output)
        if files:
            print("\n✅ 报告已保存到:")
            for f in files:
                print(f"   📄 {f}")

    except Exception as e:
        print(f"❌ 错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        tool.file_handler.cleanup()


if __name__ == '__main__':
    main()
