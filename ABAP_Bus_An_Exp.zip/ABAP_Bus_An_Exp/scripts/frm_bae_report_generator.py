#!/usr/bin/env python3
"""
ABAP Business Analysis & Explanation - Report Generator
ABAP业务逻辑分析 - 报告生成器
支持TXT/HTML/JSON输出格式，保留原代码和原注释

Author: 吴平
联系方式: 13574840501 | 微信号：wuping800223
Date: 2026-04-22
Version: 1.0.0
"""

import json
import re
import html as html_lib
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime
from dataclasses import asdict

from frm_bae_analyzer import AnalysisReport, CodeAnnotation, BusinessAnalysisResult, FileAnalysisResult


class ReportGenerator:
    """业务逻辑分析报告生成器"""
    
    REPORT_TITLE = "ABAP代码业务逻辑分析报告"
    FOOTER_AUTHOR = "Author: 吴平 | 联系方式: 13574840501 | 微信号：wuping800223"
    
    def __init__(self, output_dir: Optional[str] = None):
        self.output_dir = Path(output_dir) if output_dir else Path.cwd()
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def generate_text(self, report: AnalysisReport, output_path: Optional[str] = None) -> str:
        """生成TXT文本报告
        
        报告结构：
        - 抬头注释（整体业务逻辑分析）
        - 原代码 + 行注释
        - Footer
        """
        lines = []
        sep = '=' * 70
        
        lines.append(sep)
        lines.append(f"                    {self.REPORT_TITLE}")
        lines.append(sep)
        lines.append("")
        
        # 文件信息
        lines.append(f"  文件名称: {report.file_name}")
        lines.append(f"  文件路径: {report.file_path}")
        lines.append(f"  分析时间: {report.timestamp}")
        lines.append(f"  代码来源: {report.source_type}")
        lines.append(f"  代码行数: {report.total_lines}")
        lines.append(f"  注释条目: {len(report.annotations)}")
        lines.append("")
        
        # 涉及的表
        if report.table_refs:
            lines.append(f"  涉及数据表 ({len(report.table_refs)}): {', '.join(report.table_refs)}")
        if report.function_refs:
            lines.append(f"  调用函数模块 ({len(report.function_refs)}): {', '.join(report.function_refs)}")
        if report.program_refs:
            lines.append(f"  调用程序 ({len(report.program_refs)}): {', '.join(report.program_refs)}")
        lines.append("")
        
        # 代码块统计
        if report.block_summary:
            lines.append("-" * 70)
            lines.append("  代码块结构统计:")
            for btype, info in report.block_summary.items():
                lines.append(f"    {btype}: {info['count']} 个")
            lines.append("")
        
        # 抬头注释：整体业务逻辑分析
        lines.append(sep)
        lines.append("*ABAP_Bus_An_Exp：技术逻辑分析:")
        lines.append(sep)
        for logic_line in report.overall_logic.split('\n'):
            lines.append(f"*  {logic_line}")
        lines.append(sep)
        lines.append("")

        # ---- 目录模式：目录结构区块 ----
        if report.directory_mode and report.file_results:
            lines.append(sep)
            lines.append("  【ABAP_Bus_An_Exp：目录结构】")
            lines.append(sep)
            pool_name = getattr(report, 'program_pool', '')
            if pool_name:
                lines.append(f"  程序池: {pool_name}")
            if report.main_program:
                lines.append(f"  主程序: {report.main_program}")
            lines.append(f"  文件数量: {len(report.file_results)}")
            lines.append("")
            lines.append("  分析顺序:")
            for fr in report.file_results:
                label = "主程序" if fr.include_order == 0 else f"INCLUDE #{fr.include_order}"
                lines.append(f"    {label}: {fr.file_name} ({fr.source_type}, {fr.total_lines}行)")
            lines.append("")
            if report.directory_tree:
                lines.append("  目录树:")
                for tree_line in report.directory_tree.split('\n'):
                    lines.append(f"    {tree_line}")
            lines.append("")
            lines.append(sep)
            lines.append("")

        # 业务逻辑深度分析
        biz_text = self._build_business_analysis_text(report)
        if biz_text:
            lines.append(sep)
            lines.append(biz_text)
            lines.append(sep)
            lines.append("")

        # 代码 + 行注释
        lines.append(sep)
        lines.append("  代码详细说明（原代码 + 业务逻辑注释）:")
        lines.append(sep)
        lines.append("")
        
        # 构建行号到注释的映射
        annotation_map = {}
        for ann in report.annotations:
            annotation_map[ann.line_number] = ann
        
        # 获取原始代码行
        if report.annotations:
            max_line = max(ann.line_number for ann in report.annotations)
            
            for line_no in range(1, max_line + 1):
                ann = annotation_map.get(line_no)
                
                if ann:
                    # 代码块开始/结束的突出显示
                    if ann.is_block_start and ann.block_context:
                        lines.append(f"    * ABAP_Bus_An_Exp结构说明： [{ann.block_type}] {ann.block_context}")
                    if ann.is_block_end and ann.block_context:
                        lines.append(f"    * ABAP_Bus_An_Exp结构说明： [{ann.block_type}] {ann.block_context}")
                    
                    # 原始代码行
                    lines.append(f"  {line_no:4d}| {ann.original_code}")
                    
                    # 行级注释说明
                    if ann.explanation:
                        lines.append(f'       "ABAP_Bus_An_Exp代码说明： {ann.explanation}')
                else:
                    lines.append(f"  {line_no:4d}| ...")
        
        lines.append("")
        
        # Footer
        lines.append(sep)
        lines.append(f"报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(self.FOOTER_AUTHOR)
        lines.append(sep)
        
        content = '\n'.join(lines)
        
        if output_path:
            Path(output_path).write_text(content, encoding='utf-8')
        
        return content
    
    def generate_html(self, report: AnalysisReport, output_path: Optional[str] = None) -> str:
        """生成HTML报告
        
        美观的网页报告，包含：
        - 文件信息卡片
        - 整体业务逻辑分析
        - 代码+行注释（带语法高亮）
        - 数据表/函数引用
        - Footer
        """
        # 构建行号到注释的映射
        annotation_map = {}
        for ann in report.annotations:
            annotation_map[ann.line_number] = ann
        
        max_line = max(ann.line_number for ann in report.annotations) if report.annotations else 0
        
        # 生成代码行 HTML
        code_rows = []
        for line_no in range(1, max_line + 1):
            ann = annotation_map.get(line_no)
            
            if ann:
                escaped_code = html_lib.escape(ann.original_code)
                
                # 代码块标记
                block_start_html = ""
                block_end_html = ""
                if ann.is_block_start and ann.block_context:
                    block_start_html = f'''
                    <tr class="block-marker block-start">
                        <td colspan="2">
                            <div class="block-badge">**ABAP_Bus_An_Exp结构说明：** {html_lib.escape(ann.block_context)}</div>
                        </td>
                    </tr>'''
                if ann.is_block_end and ann.block_context:
                    block_end_html = f'''
                    <tr class="block-marker block-end">
                        <td colspan="2">
                            <div class="block-badge block-badge-end">**ABAP_Bus_An_Exp结构说明：** {html_lib.escape(ann.block_context)}</div>
                        </td>
                    </tr>'''
                
                # 行注释
                explanation_html = ""
                if ann.explanation:
                    explanation_html = f'''
                    <tr class="explanation-row">
                        <td></td>
                        <td>
                            <div class="explanation">"ABAP_Bus_An_Exp代码说明： {html_lib.escape(ann.explanation)}</div>
                        </td>
                    </tr>'''
                
                code_rows.append(block_start_html)
                code_rows.append(f'''
                <tr class="code-line">
                    <td class="line-number">{line_no}</td>
                    <td class="code-content"><code>{self._highlight_abap(escaped_code)}</code></td>
                </tr>''')
                code_rows.append(explanation_html)
                code_rows.append(block_end_html)
            else:
                code_rows.append(f'''
                <tr class="empty-line">
                    <td class="line-number">{line_no}</td>
                    <td class="code-content"></td>
                </tr>''')
        
        code_table = '\n'.join(code_rows)
        
        # ---- 目录模式增强处理 ----
        if report.directory_mode and report.file_results:
            # 目录模式：按文件分段展示代码表格
            code_table = self._build_directory_code_table_html(report)
            # 目录树 HTML
            dir_tree_html = self._build_directory_tree_html(report)
        else:
            dir_tree_html = ""
        
        # 整体业务逻辑分析 HTML
        logic_lines = report.overall_logic.split('\n')
        logic_html = '\n'.join([f'<div class="logic-line">{html_lib.escape(l)}</div>' for l in logic_lines])
        
        # 数据表引用
        table_items = ""
        if report.table_refs:
            table_items = '\n'.join([f'<span class="ref-tag table-tag">{html_lib.escape(t)}</span>' 
                                     for t in report.table_refs])
        
        # 函数模块引用
        func_items = ""
        if report.function_refs:
            func_items = '\n'.join([f'<span class="ref-tag func-tag">{html_lib.escape(f)}</span>' 
                                    for f in report.function_refs])
        
        # 代码块统计
        block_stats_html = ""
        if report.block_summary:
            stat_items = []
            for btype, info in report.block_summary.items():
                stat_items.append(f'''
                <div class="stat-item">
                    <span class="stat-name">{html_lib.escape(btype)}</span>
                    <span class="stat-count">{info["count"]}</span>
                </div>''')
            block_stats_html = f'''
            <div class="section">
                <h2>&#128202; 代码块结构统计</h2>
                <div class="stat-grid">
                    {''.join(stat_items)}
                </div>
            </div>'''
        
        # 用户提示信息 HTML


        # 业务逻辑深度分析 HTML（绿色区块）
        business_analysis_html = self._build_business_analysis_html(report)

        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.REPORT_TITLE} - {html_lib.escape(report.file_name)}</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: 'Microsoft YaHei', 'Segoe UI', Arial, sans-serif;
            background: white;
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{ max-width: 1400px; margin: 0 auto; }}
        
        /* 头部 */
        .header {{
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .header h1 {{
            color: #1e40af;
            margin-bottom: 10px;
            font-size: 28px;
        }}
        .file-info {{ color: #666; line-height: 1.8; }}
        .file-info strong {{ color: #333; }}
        
        /* 信息卡片 */
        .info-cards {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin: 20px 0;
        }}
        .info-card {{
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            color: white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }}
        .info-card.lines {{ background: linear-gradient(135deg, #1e40af, #3b82f6); }}
        .info-card.annotations {{ background: linear-gradient(135deg, #059669, #10b981); }}
        .info-card.tables {{ background: linear-gradient(135deg, #7c3aed, #a78bfa); }}
        .info-card.functions {{ background: linear-gradient(135deg, #d97706, #f59e0b); }}
        .info-card h2 {{ font-size: 2.5em; margin-bottom: 5px; }}
        .info-card p {{ font-size: 13px; opacity: 0.9; }}
        
        /* 整体业务逻辑 */
        .logic-section {{
            background: linear-gradient(135deg, #1e40af, #3b82f6);
            color: white;
            padding: 25px;
            border-radius: 16px;
            margin-bottom: 20px;
        }}
        .logic-section h2 {{
            margin-bottom: 15px;
            font-size: 20px;
            border-bottom: 2px solid rgba(255,255,255,0.3);
            padding-bottom: 10px;
        }}
        .logic-content {{
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            padding: 20px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            line-height: 1.8;
            white-space: pre-wrap;
        }}
        
        /* 引用标签 */
        .ref-section {{
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .ref-section h3 {{ color: #333; margin-bottom: 10px; font-size: 16px; }}
        .ref-tags {{ display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px; }}
        .ref-tag {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            font-family: 'Consolas', monospace;
        }}
        .table-tag {{ background: #ede9fe; color: #7c3aed; }}
        .func-tag {{ background: #fef3c7; color: #d97706; }}
        
        /* 通用段落 */
        .section {{
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .section h2 {{
            color: #333;
            border-bottom: 3px solid #1e40af;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }}
        
        /* 代码块统计 */
        .stat-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 10px;
        }}
        .stat-item {{
            background: #eff6ff;
            padding: 12px 15px;
            border-radius: 8px;
            border-left: 4px solid #1e40af;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .stat-name {{ color: #1e40af; font-size: 13px; font-family: 'Consolas', monospace; }}
        .stat-count {{
            background: #1e40af;
            color: white;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: bold;
        }}
        
        /* 代码表 */
        .code-section {{
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .code-section h2 {{
            color: #333;
            border-bottom: 3px solid #1e40af;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }}
        .code-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }}
        .code-table td {{
            padding: 0;
            vertical-align: top;
        }}
        .line-number {{
            width: 55px;
            text-align: right;
            padding: 4px 10px !important;
            color: #999;
            font-family: 'Consolas', monospace;
            font-size: 12px;
            border-right: 1px solid #e5e7eb;
            user-select: none;
        }}
        .code-content {{
            padding: 4px 15px !important;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 13px;
            line-height: 1.7;
            white-space: pre;
        }}
        .code-content code {{
            font-family: inherit;
            font-size: inherit;
        }}
        .code-line {{ background: white; }}
        .code-line:hover {{ background: #f0f9ff; }}
        .empty-line {{ height: 10px; }}
        .empty-line .line-number {{ color: #ddd; }}
        
        /* 代码块标记 */
        .block-marker td {{ padding: 0 !important; }}
        .block-badge {{
            background: #dbeafe;
            border-left: 4px solid #1e40af;
            padding: 6px 15px;
            font-size: 12px;
            color: #1e40af;
            font-weight: 600;
            word-break: break-all;
            overflow-wrap: break-word;
        }}
        .block-badge-end {{
            background: #fef3c7;
            border-left-color: #d97706;
            color: #d97706;
        }}
        
        /* 行注释说明 */
        .explanation-row td {{ padding: 0 !important; }}
        .explanation {{
            background: #f0fdf4;
            border-left: 4px solid #059669;
            padding: 4px 15px;
            font-size: 12px;
            color: #166534;
            font-style: italic;
            line-height: 1.6;
        }}
        
        /* ABAP 语法高亮 */
        .kw {{ color: #1e40af; font-weight: bold; }}
        .cm {{ color: #059669; font-style: italic; }}
        .str {{ color: #d97706; }}
        .num {{ color: #7c3aed; }}
        
        /* 业务逻辑深度分析（绿色区块） */
        .biz-analysis-section {{
            background: linear-gradient(135deg, #059669, #10b981);
            color: white;
            padding: 25px;
            border-radius: 16px;
            margin-bottom: 20px;
        }}
        .biz-analysis-section h2 {{
            margin-bottom: 15px;
            font-size: 20px;
            border-bottom: 2px solid rgba(255,255,255,0.3);
            padding-bottom: 10px;
        }}
        .biz-analysis-content {{
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            padding: 20px;
            font-size: 14px;
            line-height: 1.8;
        }}
        .biz-analysis-content > div {{
            margin-bottom: 10px;
        }}
        .biz-module-item {{
            margin-left: 16px;
            margin-bottom: 6px;
            padding-left: 10px;
            border-left: 3px solid rgba(255,255,255,0.5);
        }}

        /* 目录结构区块（橙色） */
        .directory-section {{
            background: linear-gradient(135deg, #d97706, #f59e0b);
            color: #5c3d1e;
            padding: 25px;
            border-radius: 16px;
            margin-bottom: 20px;
        }}
        .directory-section h2 {{
            margin-bottom: 15px;
            font-size: 20px;
            border-bottom: 2px solid rgba(92, 61, 30, 0.3);
            padding-bottom: 10px;
            color: #451a03;
        }}
        .directory-content {{
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            padding: 20px;
            font-size: 14px;
            line-height: 1.8;
            color: #5c3d1e;
        }}

        /* 文件分隔标题 */
        .file-separator td {{ padding: 0 !important; }}
        .file-separator-badge {{
            background: #f0f9ff;
            border-left: 4px solid #1e40af;
            padding: 8px 15px;
            font-size: 14px;
            font-weight: 600;
            color: #1e40af;
        }}
        

        /* Footer */
        .footer {{
            text-align: center;
            color: #333;
            padding: 20px;
            font-size: 14px;
            border-top: 2px solid #1e40af;
            margin-top: 30px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{self.REPORT_TITLE}</h1>
            <div class="file-info">
                <p><strong>文件名称:</strong> {html_lib.escape(report.file_name)}</p>
                <p><strong>文件路径:</strong> {html_lib.escape(report.file_path)}</p>
                <p><strong>分析时间:</strong> {report.timestamp}</p>
                <p><strong>代码来源:</strong> {html_lib.escape(report.source_type)}</p>
            </div>
        </div>
        
        <div class="info-cards">
            <div class="info-card lines">
                <h2>{report.total_lines}</h2>
                <p>代码总行数</p>
            </div>
            <div class="info-card annotations">
                <h2>{len(report.annotations)}</h2>
                <p>注释说明条目</p>
            </div>
            <div class="info-card tables">
                <h2>{len(report.table_refs)}</h2>
                <p>数据表引用</p>
            </div>
            <div class="info-card functions">
                <h2>{len(report.function_refs)}</h2>
                <p>函数模块调用</p>
            </div>
        </div>
        
        <div class="logic-section">
            <h2>&#9881; ABAP_Bus_An_Exp：技术逻辑分析</h2>
            <div class="logic-content">
{logic_html}
            </div>
        </div>
        
        {dir_tree_html}
        
        {business_analysis_html}
        
        <div class="ref-section">
            <h3>数据表引用</h3>
            <div class="ref-tags">
                {table_items if table_items else '<span style="color:#999">未检测到数据表引用</span>'}
            </div>
        </div>
        
        <div class="ref-section">
            <h3>函数模块调用</h3>
            <div class="ref-tags">
                {func_items if func_items else '<span style="color:#999">未检测到函数模块调用</span>'}
            </div>
        </div>
        
        {block_stats_html}

        <div class="code-section">
            <h2>代码详细说明</h2>
            <table class="code-table">
                <tbody>
                    {code_table}
                </tbody>
            </table>
        </div>
        
        <div class="footer">
            <p>报告生成时间: {current_time}</p>
            <p>{self.FOOTER_AUTHOR}</p>
        </div>
    </div>
</body>
</html>"""
        
        if output_path:
            Path(output_path).write_text(html_content, encoding='utf-8')
        
        return html_content
    
    def generate_json(self, report: AnalysisReport, output_path: Optional[str] = None) -> str:
        """生成JSON报告"""
        json_data = {
            'report_type': 'ABAP_Bus_An_Exp：技术逻辑分析',
            'file_name': report.file_name,
            'file_path': report.file_path,
            'timestamp': report.timestamp,
            'total_lines': report.total_lines,
            'source_type': report.source_type,
            'overall_logic': report.overall_logic,
            'table_refs': report.table_refs,
            'function_refs': report.function_refs,
            'program_refs': report.program_refs,
            'block_summary': report.block_summary,
            'annotations': [ann.to_dict() for ann in report.annotations],
            '_author': '吴平',
            '_contact': '13574840501',
            '_wechat': 'wuping800223',
            '_report_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'user_hints': getattr(report, 'user_hints', []),
            'business_analysis': asdict(report.business_analysis) if report.business_analysis else None,
        }

        # 目录模式附加字段
        if report.directory_mode:
            json_data['directory_mode'] = True
            json_data['directory_tree'] = report.directory_tree
            json_data['main_program'] = report.main_program
            json_data['program_pool'] = getattr(report, 'program_pool', '')
            json_data['file_results'] = [
                {
                    'file_name': fr.file_name,
                    'file_path': fr.file_path,
                    'source_type': fr.source_type,
                    'total_lines': fr.total_lines,
                    'include_order': fr.include_order,
                    'overall_logic': fr.overall_logic,
                    'table_refs': fr.table_refs,
                    'function_refs': fr.function_refs,
                    'business_analysis': asdict(fr.business_analysis) if fr.business_analysis else None,
                }
                for fr in report.file_results
            ]

        content = json.dumps(json_data, ensure_ascii=False, indent=2)
        
        if output_path:
            Path(output_path).write_text(content, encoding='utf-8')
        
        return content
    
    def _highlight_abap(self, code: str) -> str:
        """简单的ABAP语法高亮
        
        对关键字、注释、字符串、数字进行着色
        """
        # 注释行（以 * 开头）
        if code.strip().startswith('*'):
            return f'<span class="cm">{code}</span>'
        
        # 行内注释（" 开头）
        comment_pos = -1
        in_string = False
        for i, ch in enumerate(code):
            if ch == "'" and (i == 0 or code[i-1] != "'"):
                in_string = not in_string
            if not in_string and ch == '"':
                comment_pos = i
                break
        
        code_part = code
        comment_part = ""
        if comment_pos >= 0:
            code_part = code[:comment_pos]
            comment_part = f'<span class="cm">{code[comment_pos:]}</span>'
        
        # 保护字符串
        strings = []
        def protect_string(m):
            idx = len(strings)
            strings.append(f'<span class="str">{m.group(0)}</span>')
            return f'\x00STR{idx}\x00'
        
        code_part = re.sub(r"'[^']*'", protect_string, code_part)
        
        # 高亮数字
        code_part = re.sub(r'\b(\d+)\b', r'<span class="num">\1</span>', code_part)
        
        # ABAP 关键字高亮
        keywords = [
            r'\bSELECT\b', r'\bINTO\b', r'\bFROM\b', r'\bWHERE\b',
            r'\bAND\b', r'\bOR\b', r'\bNOT\b',
            r'\bLOOP\b', r'\bAT\b', r'\bENDLOOP\b',
            r'\bIF\b', r'\bELSE\b', r'\bELSEIF\b', r'\bENDIF\b',
            r'\bCASE\b', r'\bWHEN\b', r'\bENDCASE\b',
            r'\bWHILE\b', r'\bENDWHILE\b', r'\bDO\b', r'\bENDDO\b',
            r'\bFORM\b', r'\bENDFORM\b', r'\bPERFORM\b',
            r'\bFUNCTION\b', r'\bENDFUNCTION\b',
            r'\bMETHOD\b', r'\bENDMETHOD\b', r'\bCLASS\b', r'\bENDCLASS\b',
            r'\bDATA\b', r'\bTYPES\b', r'\bCONSTANTS\b', r'\bSTATICS\b',
            r'\bFIELD-SYMBOLS\b', r'\bTABLES\b', r'\bPARAMETERS\b',
            r'\bSELECT-OPTIONS\b', r'\bRANGES\b',
            r'\bWRITE\b', r'\bULINE\b', r'\bSKIP\b', r'\bNEW-PAGE\b',
            r'\bCALL\b', r'\bSUBMIT\b', r'\bLEAVE\b', r'\bEXIT\b', r'\bRETURN\b',
            r'\bCONTINUE\b', r'\bCHECK\b',
            r'\bCLEAR\b', r'\bREFRESH\b', r'\bFREE\b', r'\bMOVE\b',
            r'\bCONCATENATE\b', r'\bSPLIT\b', r'\bSHIFT\b', r'\bTRANSLATE\b',
            r'\bREPLACE\b', r'\bAPPEND\b', r'\bCOLLECT\b', r'\bINSERT\b',
            r'\bDELETE\b', r'\bMODIFY\b', r'\bREAD\b', r'\bSORT\b', r'\bDESCRIBE\b',
            r'\bMESSAGE\b', r'\bAUTHORITY-CHECK\b',
            r'\bREPORT\b', r'\bPROGRAM\b', r'\bINCLUDE\b',
            r'\bBEGIN\b', r'\bEND\b', r'\bOF\b', r'\bOCCURS\b',
            r'\bTYPE\b', r'\bLIKE\b',
            r'\bJOIN\b', r'\bINNER\b', r'\bLEFT\b', r'\bRIGHT\b',
            r'\bGROUP\b', r'\bBY\b', r'\bORDER\b', r'\bHAVING\b',
            r'\bDISTINCT\b', r'\bUP\b', r'\bTO\b', r'\bROWS\b', r'\bSINGLE\b',
            r'\bINDEX\b', r'\bUSING\b', r'\bCHANGING\b', r'\bTABLE\b',
            r'\bCREATE\b', r'\bOBJECT\b', r'\bRAISE\b', r'\bEVENT\b',
            r'\bSET\b', r'\bHANDLER\b',
            r'\bTRY\b', r'\bCATCH\b', r'\bCLEANUP\b', r'\bENDTRY\b',
            r'\bPROVIDE\b', r'\bENDPROVIDE\b',
            r'\bIS\b', r'\bINITIAL\b', r'\bASSIGNED\b', r'\bBOUND\b',
            r'\bBETWEEN\b', r'\bIN\b', r'\bLIKE\b',
            r'\bGE\b', r'\bGT\b', r'\bLE\b', r'\bLT\b', r'\bEQ\b', r'\bNE\b',
        ]
        
        kw_pattern = '|'.join(keywords)
        code_part = re.sub(kw_pattern, r'<span class="kw">\g<0></span>', code_part, flags=re.IGNORECASE)
        
        # 恢复字符串
        for idx, s in enumerate(strings):
            code_part = code_part.replace(f'\x00STR{idx}\x00', s)
        
        return code_part + comment_part
    
    def _build_business_analysis_html(self, report: AnalysisReport) -> str:
        """构建业务逻辑深度分析的 HTML 区块（绿色）"""
        ba = report.business_analysis
        if not ba or not ba.program_position:
            return ""
        
        parts = []
        
        # 程序定位
        if ba.program_position:
            parts.append(f'<div><strong>程序定位：</strong>{html_lib.escape(ba.program_position)}</div>')
        
        # 业务领域
        if ba.business_domain:
            parts.append(f'<div><strong>业务领域：</strong>{html_lib.escape(ba.business_domain)}</div>')
        
        # 功能模块
        if ba.functional_modules:
            parts.append('<div><strong>核心功能模块：</strong></div>')
            for mod in ba.functional_modules:
                parts.append(f'<div class="biz-module-item">&#x1F4CB; {html_lib.escape(mod)}</div>')
        
        # 关键业务表
        if ba.key_tables_desc:
            parts.append(f'<div style="margin-top: 10px;"><strong>关键数据对象：</strong><br>{html_lib.escape(ba.key_tables_desc).replace(chr(10), "<br>")}</div>')
        
        # 技术特征
        if ba.technical_features:
            parts.append(f'<div style="margin-top: 10px;"><strong>技术特征：</strong>{html_lib.escape(ba.technical_features)}</div>')
        
        content_html = '\n'.join(parts)
        
        return f'''
        <div class="biz-analysis-section">
            <h2>&#127919; ABAP_Bus_An_Exp：业务逻辑分析（深度解析）</h2>
            <div class="biz-analysis-content">
{content_html}
            </div>
        </div>'''
    
    def _build_business_analysis_text(self, report: AnalysisReport) -> str:
        """构建业务逻辑深度分析的 TXT 文本"""
        ba = report.business_analysis
        if not ba or not ba.program_position:
            return ""
        
        parts = []
        parts.append("【ABAP_Bus_An_Exp：业务逻辑分析（深度解析）】")
        parts.append("")
        
        if ba.program_position:
            parts.append(f"  程序定位: {ba.program_position}")
        if ba.business_domain:
            parts.append(f"  业务领域: {ba.business_domain}")
        
        if ba.functional_modules:
            parts.append("")
            parts.append("  核心功能模块:")
            for mod in ba.functional_modules:
                parts.append(f"    - {mod}")
        
        if ba.key_tables_desc:
            parts.append("")
            parts.append(f"  关键数据对象:")
            for line in ba.key_tables_desc.split('\n'):
                parts.append(f"    {line}")
        
        if ba.technical_features:
            parts.append("")
            parts.append(f"  技术特征: {ba.technical_features}")
        
        return '\n'.join(parts)

    # ============================================================
    # 目录模式报告辅助方法
    # ============================================================

    def _build_directory_tree_html(self, report: AnalysisReport) -> str:
        """构建目录结构的 HTML 区块"""
        if not report.directory_mode or not report.directory_tree:
            return ""

        tree_escaped = html_lib.escape(report.directory_tree).replace('\n', '<br>')
        tree_escaped = tree_escaped.replace('    ', '&nbsp;&nbsp;&nbsp;&nbsp;')

        # 文件列表信息
        file_count = len(report.file_results)

        # 程序池标签
        pool_label = ""
        pool_name = getattr(report, 'program_pool', '')
        if pool_name and pool_name != report.main_program:
            pool_label = f"<span style='color:#7c2d12;font-weight:600;'>程序池: {html_lib.escape(pool_name)}</span>"
        elif pool_name and pool_name == report.main_program:
            pool_label = f"<span style='color:#7c2d12;font-weight:600;'>程序池: {html_lib.escape(pool_name)}（同主程序）</span>"

        # 主程序标签
        main_label = ""
        if report.main_program:
            main_label = f"<span style='color:#1e40af;font-weight:600;margin-left:12px;'>主程序: {html_lib.escape(report.main_program)}</span>"

        include_list = ""
        if report.file_results:
            items = []
            for fr in report.file_results:
                if fr.include_order == 0:
                    label = "主程序"
                    style = "color:#1e40af;font-weight:600;"
                else:
                    label = f"INCLUDE #{fr.include_order}"
                    style = "color:#059669;"
                items.append(
                    f'<li style="{style}">{label}: {html_lib.escape(fr.file_name)} '
                    f'<span style="color:#999;">({fr.source_type}, {fr.total_lines}行)</span></li>'
                )
            include_list = '<ul style="list-style:none;padding:0;margin-top:8px;">' + ''.join(items) + '</ul>'

        return f'''
        <div class="directory-section">
            <h2>&#128193; ABAP_Bus_An_Exp：目录结构</h2>
            <div class="directory-content">
                <div style="margin-bottom:12px;">
                    {pool_label}{main_label}
                    <span style="margin-left:12px;color:#666;">共 {file_count} 个文件</span>
                </div>
                <div style="background:#fefce8;border-radius:8px;padding:15px;font-family:Consolas,monospace;font-size:13px;line-height:1.6;margin-bottom:12px;color:#5c3d1e;border:1px solid #d4a574;">
                    {tree_escaped}
                </div>
                <div style="font-size:13px;color:#5c3d1e;">
                    <strong style="color:#5c3d1e;">分析顺序：</strong>
                    {include_list}
                </div>
            </div>
        </div>'''

    def _build_directory_code_table_html(self, report: AnalysisReport) -> str:
        """目录模式：按文件分段构建代码表格 HTML

        程序池文件使用浅黄色背景，INCLUDE 文件使用白色背景。
        """
        if not report.file_results:
            return ""

        pool_name = getattr(report, 'program_pool', '')
        all_rows = []
        global_line = 0  # 全局行号追踪（为了显示正确偏移后的行号）

        for fr in report.file_results:
            is_main = (fr.include_order == 0)
            is_pool = (pool_name and fr.file_name.lower() == pool_name.lower())
            label = "程序池" if is_pool and not is_main else ("主程序" if is_main else f"INCLUDE #{fr.include_order}")

            # 程序池文件用浅黄色背景色值，INCLUDE文件无背景色
            bg_color = "#fefce8" if is_pool else ""
            bg_style = f"background:{bg_color};" if bg_color else ""

            # 文件分隔标题
            if is_pool:
                file_label_color = "#92400e"  # 深棕色（程序池）
            elif is_main:
                file_label_color = "#1e40af"  # 蓝色（主程序）
            else:
                file_label_color = "#059669"  # 绿色（INCLUDE）
            file_label = f"&#128196; [{label}] {html_lib.escape(fr.file_name)} — {fr.source_type} ({fr.total_lines}行)"
            badge_bg = "#fef3c7" if is_pool else "#f0f9ff"
            all_rows.append(f'''
            <tr class="file-separator">
                <td colspan="2">
                    <div class="file-separator-badge" style="border-left-color:{file_label_color};background:{badge_bg};">
                        {file_label}
                    </div>
                </td>
            </tr>''')

            # 该文件的 annotations（行号是已经偏移过的）
            annotation_map = {}
            for ann in fr.annotations:
                annotation_map[ann.line_number] = ann

            max_line = max((ann.line_number for ann in fr.annotations), default=0)

            for line_no in range(global_line + 1, global_line + max_line + 1):
                ann = annotation_map.get(line_no)

                if ann:
                    escaped_code = html_lib.escape(ann.original_code)

                    block_start_html = ""
                    block_end_html = ""
                    if ann.is_block_start and ann.block_context:
                        block_start_html = f'''
                    <tr class="block-marker block-start" style="{bg_style}">
                        <td colspan="2">
                             <div class="block-badge">**ABAP_Bus_An_Exp结构说明：** {html_lib.escape(ann.block_context)}</div>
                        </td>
                    </tr>'''
                    if ann.is_block_end and ann.block_context:
                        block_end_html = f'''
                    <tr class="block-marker block-end" style="{bg_style}">
                        <td colspan="2">
                            <div class="block-badge block-badge-end">**ABAP_Bus_An_Exp结构说明：** {html_lib.escape(ann.block_context)}</div>
                        </td>
                    </tr>'''

                    explanation_html = ""
                    if ann.explanation:
                        explanation_html = f'''
                    <tr class="explanation-row" style="{bg_style}">
                        <td></td>
                        <td>
                            <div class="explanation">"ABAP_Bus_An_Exp代码说明： {html_lib.escape(ann.explanation)}</div>
                        </td>
                    </tr>'''

                    all_rows.append(block_start_html)
                    all_rows.append(f'''
                <tr class="code-line" style="{bg_style}">
                    <td class="line-number">{line_no}</td>
                    <td class="code-content"><code>{self._highlight_abap(escaped_code)}</code></td>
                </tr>''')
                    all_rows.append(explanation_html)
                    all_rows.append(block_end_html)
                else:
                    all_rows.append(f'''
                <tr class="empty-line" style="{bg_style}">
                    <td class="line-number">{line_no}</td>
                    <td class="code-content"></td>
                </tr>''')

            global_line += max_line

        return '\n'.join(all_rows)
