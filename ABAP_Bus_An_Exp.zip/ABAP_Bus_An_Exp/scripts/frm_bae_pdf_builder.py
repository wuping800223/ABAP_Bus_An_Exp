#!/usr/bin/env python3
"""
ABAP Business Analysis & Explanation - PDF Builder
ABAPABAP_Bus_An_Exp：业务逻辑分析 - PDF报告构建器（基于 reportlab）

Author: 吴平
联系方式: 13574840501 | 微信号：wuping800223
Date: 2026-04-22
Version: 1.0.0
"""

import os
import sys
from pathlib import Path
from typing import Optional, List
from datetime import datetime


def _check_reportlab_available() -> bool:
    """检查 reportlab 是否可用"""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet
        return True
    except ImportError:
        return False


class AnalysisPDFGenerator:
    """PDF报告构建器 - 从HTML转PDF（纯 reportlab 实现）"""
    
    FOOTER_AUTHOR = "Author: 吴平 | 联系方式: 13574840501 | 微信号：wuping800223"
    
    def __init__(self, silent=False):
        self.library = 'reportlab' if _check_reportlab_available() else None
        
        if not self.library and not silent:
            print("  ⚠️ 警告: 未安装PDF生成库 (reportlab)")
            print("  请运行以下命令安装:")
            print("  pip install reportlab")
    
    def generate_from_html(self, html_path: str, pdf_path: str) -> bool:
        """从HTML文件生成PDF
        
        Args:
            html_path: HTML报告文件路径
            pdf_path: 输出PDF文件路径
            
        Returns:
            bool: 是否成功
        """
        if not self.library:
            return False
        
        if not Path(html_path).exists():
            print(f"  ⚠️ HTML文件不存在: {html_path}")
            return False
        
        try:
            html_content = Path(html_path).read_text(encoding='utf-8')
        except Exception as e:
            print(f"  ⚠️ 读取HTML失败: {e}")
            return False
        
        return self._generate_with_reportlab(html_content, pdf_path)
    
    def generate_from_content(self, html_content: str, pdf_path: str) -> bool:
        """从HTML内容字符串生成PDF"""
        if not self.library:
            return False
        return self._generate_with_reportlab(html_content, pdf_path)
    
    def _generate_with_reportlab(self, html_content: str, output_path: str) -> bool:
        """使用 reportlab 生成 PDF
        
        从HTML中提取关键内容，用 reportlab 排版输出
        """
        try:
            import re
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.platypus import (
                SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                HRFlowable, Preformatted
            )
            from reportlab.lib import colors
            from reportlab.lib.units import cm
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont
            
            # 尝试注册中文字体
            font_registered = False
            chinese_fonts = [
                ('SimHei', 'C:/Windows/Fonts/simhei.ttf'),
                ('SimSun', 'C:/Windows/Fonts/simsun.ttc'),
                ('Microsoft YaHei', 'C:/Windows/Fonts/msyh.ttc'),
                ('Microsoft YaHei', 'C:/Windows/Fonts/msyh.ttf'),
            ]
            for font_name, font_path in chinese_fonts:
                if Path(font_path).exists():
                    try:
                        pdfmetrics.registerFont(TTFont(font_name, font_path))
                        font_registered = True
                        break
                    except Exception:
                        continue
            
            # 输出目录
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            doc = SimpleDocTemplate(
                output_path,
                pagesize=A4,
                leftMargin=2*cm,
                rightMargin=2*cm,
                topMargin=2*cm,
                bottomMargin=2*cm
            )
            
            styles = getSampleStyleSheet()
            fn = 'SimHei' if font_registered else 'Helvetica'
            fn_mono = 'SimSun' if font_registered else 'Courier'
            
            # 自定义样式
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontName=fn, fontSize=20, spaceAfter=20,
                textColor=colors.HexColor('#1e40af'), alignment=1
            )
            heading2_style = ParagraphStyle(
                'Heading2Custom',
                parent=styles['Heading2'],
                fontName=fn, fontSize=14,
                textColor=colors.HexColor('#1e40af'),
                spaceBefore=15, spaceAfter=10
            )
            body_style = ParagraphStyle(
                'BodyCustom',
                parent=styles['Normal'],
                fontName=fn, fontSize=10, leading=16, spaceAfter=5
            )
            code_style = ParagraphStyle(
                'CodeCustom',
                parent=styles['Code'],
                fontName=fn_mono, fontSize=8, leading=11,
                backColor=colors.HexColor('#f8f9fa'),
                leftIndent=10, rightIndent=10
            )
            comment_style = ParagraphStyle(
                'CommentCustom',
                parent=styles['Normal'],
                fontName=fn, fontSize=9, leading=13,
                textColor=colors.HexColor('#166534'),
                leftIndent=30, spaceAfter=2
            )
            
            # 构建文档内容
            story = []
            
            # 标题
            story.append(Paragraph("ABAP代码ABAP_Bus_An_Exp：业务逻辑分析报告", title_style))
            story.append(Spacer(1, 10))
            story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#1e40af')))
            story.append(Spacer(1, 15))
            
            # 文件信息
            file_name = self._extract_html_text(html_content, '文件名称')
            file_path = self._extract_html_text(html_content, '文件路径')
            timestamp = self._extract_html_text(html_content, '分析时间')
            source_type = self._extract_html_text(html_content, '代码来源')
            
            info_data = [
                ['文件名称', file_name],
                ['文件路径', file_path],
                ['分析时间', timestamp],
                ['代码来源', source_type],
            ]
            
            info_table = Table(info_data, colWidths=[3*cm, 13*cm])
            info_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, -1), fn),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#eff6ff')),
                ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#1e40af')),
                ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e5e7eb')),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ]))
            story.append(info_table)
            story.append(Spacer(1, 20))
            
            # ABAP_Bus_An_Exp：业务逻辑分析
            logic_content = self._extract_logic_content(html_content)
            if logic_content:
                story.append(Paragraph("*ABAP_Bus_An_Exp：技术逻辑分析", heading2_style))
                story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#e5e7eb')))
                for line in logic_content:
                    if line.strip():
                        safe_line = line.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                        story.append(Paragraph(safe_line, body_style))
                story.append(Spacer(1, 15))
            
            # 数据表和函数引用
            table_refs = self._extract_refs(html_content, 'table-tag')
            func_refs = self._extract_refs(html_content, 'func-tag')
            
            if table_refs:
                story.append(Paragraph("涉及数据表", heading2_style))
                story.append(Paragraph(", ".join(table_refs), body_style))
                story.append(Spacer(1, 10))
            
            if func_refs:
                story.append(Paragraph("函数模块调用", heading2_style))
                story.append(Paragraph(", ".join(func_refs), body_style))
                story.append(Spacer(1, 10))
            
            # 代码行和注释
            code_lines = self._extract_code_lines(html_content)
            if code_lines:
                story.append(Paragraph("代码详细说明", heading2_style))
                story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#e5e7eb')))
                story.append(Spacer(1, 10))
                
                for item in code_lines:
                    line_type = item.get('type', 'code')
                    text = item.get('text', '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                    
                    if not text.strip():
                        story.append(Spacer(1, 3))
                    elif line_type == 'block':
                        story.append(Paragraph(f"<b>{text}</b>", comment_style))
                    elif line_type == 'explanation':
                        safe_text = text.replace('"ABAP_Bus_An_Exp代码说明:', '').strip()
                        story.append(Paragraph(f'"{safe_text}', comment_style))
                    elif line_type == 'code':
                        try:
                            story.append(Preformatted(text, code_style))
                        except Exception:
                            story.append(Paragraph(text, code_style))
            
            # Footer
            story.append(Spacer(1, 30))
            story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#1e40af')))
            story.append(Spacer(1, 10))
            
            footer_style = ParagraphStyle(
                'FooterCustom',
                parent=styles['Normal'],
                fontName=fn, fontSize=9,
                textColor=colors.HexColor('#666666'), alignment=1
            )
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            story.append(Paragraph(f"报告生成时间: {current_time}", footer_style))
            story.append(Paragraph(self.FOOTER_AUTHOR, footer_style))
            
            doc.build(story)
            return True
            
        except Exception as e:
            print(f"  ⚠️ PDF生成失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _extract_html_text(self, html: str, label: str, default: str = '') -> str:
        """从HTML中提取标签后的文本"""
        import re
        pattern = rf'<strong>{re.escape(label)}.*?</strong>\s*([^<]+)'
        match = re.search(pattern, html)
        return match.group(1).strip() if match else default
    
    def _extract_logic_content(self, html: str) -> List[str]:
        """从HTML中提取ABAP_Bus_An_Exp：业务逻辑分析内容"""
        import re
        match = re.search(r'class="logic-content"[^>]*>(.*?)</div>', html, re.DOTALL)
        if not match:
            return []
        content = match.group(1)
        content = re.sub(r'<[^>]+>', '', content)
        return [l.strip() for l in content.split('\n') if l.strip()]
    
    def _extract_refs(self, html: str, css_class: str) -> List[str]:
        """从HTML中提取引用标签"""
        import re
        pattern = rf'class="{re.escape(css_class)}"[^>]*>([^<]+)</span>'
        return re.findall(pattern, html)
    
    def _extract_code_lines(self, html: str) -> List[dict]:
        """从HTML中提取代码行和注释"""
        import re
        results = []
        
        for match in re.finditer(r'class="block-badge[^"]*"[^>]*>([^<]+)</div>', html):
            text = re.sub(r'<[^>]+>', '', match.group(1)).strip()
            if text.startswith('\u2605 '):
                text = text[2:]
            results.append({'type': 'block', 'text': text})
        
        for match in re.finditer(r'class="explanation"[^>]*>([^<]+)</div>', html):
            results.append({'type': 'explanation', 'text': match.group(1).strip()})
        
        for match in re.finditer(r'class="code-content"[^>]*>\s*<code>([^<]*)</code>', html):
            text = match.group(1).strip()
            if text:
                results.append({'type': 'code', 'text': text})
        
        return results
