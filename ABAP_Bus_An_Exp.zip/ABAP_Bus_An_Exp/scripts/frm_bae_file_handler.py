#!/usr/bin/env python3
"""
ABAP Business Analysis & Explanation - File Handler
ABAP业务逻辑分析 - 文件输入处理器
处理TXT/MD/ZIP/RAR文件及代码片段输入

Author: 吴平
联系方式: 13574840501 | 微信号：wuping800223
Date: 2026-04-22
Version: 1.0.0
"""

import re
import os
import zipfile
import tempfile
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class FileType(Enum):
    """支持的文件类型"""
    TXT = "txt"
    MD = "md"
    ZIP = "zip"
    RAR = "rar"
    SNIPPET = "snippet"
    UNKNOWN = "unknown"


@dataclass
class ABAPFile:
    """ABAP文件对象"""
    file_name: str
    file_path: str
    content: str
    file_type: str
    source_type: str = "UNKNOWN"
    size: int = 0
    
    def __post_init__(self):
        if self.size == 0:
            self.size = len(self.content)


class FileHandler:
    """文件输入处理器"""
    
    ABAP_EXTENSIONS = {'.abap', '.prog', '.txt', '.source', '.代码'}
    
    RAR_AVAILABLE = False
    try:
        import rarfile
        RAR_AVAILABLE = True
    except ImportError:
        pass
    
    def __init__(self, temp_dir: Optional[str] = None):
        self.temp_dir = temp_dir or tempfile.gettempdir()
        self.temp_dir = Path(self.temp_dir)
        self.extracted_files: List[Path] = []
    
    def detect_file_type(self, file_path: str) -> FileType:
        """检测文件类型"""
        path = Path(file_path)
        suffix = path.suffix.lower()
        
        if suffix == '.txt':
            return FileType.TXT
        elif suffix == '.md':
            return FileType.MD
        elif suffix == '.zip':
            return FileType.ZIP
        elif suffix in ('.rar', '.cbr'):
            return FileType.RAR
        else:
            return FileType.UNKNOWN
    
    def is_abap_file(self, file_name: str) -> bool:
        """判断是否为ABAP文件"""
        path = Path(file_name)
        suffix = path.suffix.lower()
        return suffix in self.ABAP_EXTENSIONS
    
    def process_file(self, file_path: str) -> List[ABAPFile]:
        """处理文件或目录，支持TXT/MD/ZIP/RAR/目录"""
        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"路径不存在: {file_path}")
        
        # 支持目录输入
        if path.is_dir():
            return self._process_directory(path)
        
        file_type = self.detect_file_type(file_path)
        
        if file_type == FileType.TXT:
            return self._process_txt(path)
        elif file_type == FileType.MD:
            return self._process_md(path)
        elif file_type == FileType.ZIP:
            return self._process_zip(path)
        elif file_type == FileType.RAR:
            return self._process_rar(path)
        else:
            # 尝试按ABAP文件直接读取
            return self._process_txt(path)
    
    def process_snippet(self, code: str, name: str = "snippet") -> List[ABAPFile]:
        """处理代码片段输入"""
        if not code or not code.strip():
            return []
        
        # 清理代码片段
        code = code.strip()
        
        # 去除Markdown代码块标记
        code = re.sub(r'^```(?:abap)?\s*\n?', '', code)
        code = re.sub(r'\n?```\s*$', '', code)
        
        return [ABAPFile(
            file_name=f"{name}.abap",
            file_path=f"<snippet:{name}>",
            content=code,
            file_type="snippet",
            source_type="SNIPPET",
            size=len(code)
        )]
    
    def _process_txt(self, path: Path) -> List[ABAPFile]:
        """处理TXT文件"""
        try:
            content = path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            try:
                content = path.read_text(encoding='gbk')
            except UnicodeDecodeError:
                content = path.read_text(encoding='latin-1')
        
        if not content.strip():
            return []
        
        source_type = self._detect_source_type(content)
        
        return [ABAPFile(
            file_name=path.name,
            file_path=str(path.resolve()),
            content=content,
            file_type="txt",
            source_type=source_type,
            size=path.stat().st_size
        )]
    
    def _process_md(self, path: Path) -> List[ABAPFile]:
        """处理Markdown文件，提取代码块"""
        try:
            content = path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            content = path.read_text(encoding='gbk')
        
        if not content.strip():
            return []
        
        results = []
        # 提取Markdown中的ABAP代码块
        code_blocks = re.findall(r'```(?:abap)?\s*\n(.*?)```', content, re.DOTALL)
        
        if not code_blocks:
            # 没有代码块则当作纯文本处理
            return self._process_txt(path)
        
        for i, block in enumerate(code_blocks):
            if block.strip():
                results.append(ABAPFile(
                    file_name=f"{path.stem}_block{i+1}.abap",
                    file_path=str(path.resolve()),
                    content=block.strip(),
                    file_type="md",
                    source_type="MARKDOWN",
                    size=len(block)
                ))
        
        return results
    
    def _process_zip(self, path: Path) -> List[ABAPFile]:
        """处理ZIP压缩包"""
        results = []
        
        try:
            with zipfile.ZipFile(path, 'r') as zf:
                for info in zf.infolist():
                    if info.is_dir():
                        continue
                    
                    fname = info.filename
                    if not self.is_abap_file(fname):
                        # 也尝试读取非标准扩展名的文件
                        if not any(fname.endswith(ext) for ext in ['.txt', '.abap', '.prog', '.source']):
                            continue
                    
                    try:
                        content = zf.read(info.filename).decode('utf-8')
                    except UnicodeDecodeError:
                        try:
                            content = zf.read(info.filename).decode('gbk')
                        except UnicodeDecodeError:
                            continue
                    
                    if content.strip():
                        source_type = self._detect_source_type(content)
                        results.append(ABAPFile(
                            file_name=os.path.basename(fname),
                            file_path=f"<zip:{path.name}/{fname}>",
                            content=content,
                            file_type="zip",
                            source_type=source_type,
                            size=info.file_size
                        ))
        except zipfile.BadZipFile:
            raise ValueError(f"无效的ZIP文件: {path}")
        
        return results
    
    def _process_rar(self, path: Path) -> List[ABAPFile]:
        """处理RAR压缩包"""
        if not self.RAR_AVAILABLE:
            raise ImportError("需要安装 rarfile 库: pip install rarfile")
        
        results = []
        
        try:
            import rarfile
            with rarfile.RarFile(path, 'r') as rf:
                for info in rf.infolist():
                    if info.is_dir():
                        continue
                    
                    fname = info.filename
                    if not self.is_abap_file(fname):
                        if not any(fname.endswith(ext) for ext in ['.txt', '.abap', '.prog', '.source']):
                            continue
                    
                    try:
                        content = rf.read(info.filename).decode('utf-8')
                    except UnicodeDecodeError:
                        try:
                            content = rf.read(info.filename).decode('gbk')
                        except UnicodeDecodeError:
                            continue
                    
                    if content.strip():
                        source_type = self._detect_source_type(content)
                        results.append(ABAPFile(
                            file_name=os.path.basename(fname),
                            file_path=f"<rar:{path.name}/{fname}>",
                            content=content,
                            file_type="rar",
                            source_type=source_type,
                            size=info.file_size
                        ))
        except Exception as e:
            raise ValueError(f"解压RAR失败: {e}")
        
        return results
    
    def _process_directory(self, path: Path) -> List[ABAPFile]:
        """递归处理目录下所有ABAP文件"""
        results = []
        
        for file_path in sorted(path.rglob('*')):
            if file_path.is_file() and (self.is_abap_file(file_path.name) or
                                        file_path.suffix.lower() in {'.txt', '.md', '.zip', '.rar'}):
                try:
                    files = self.process_file(str(file_path))
                    results.extend(files)
                except Exception as e:
                    print(f"  ⚠️ 跳过文件 {file_path.name}: {e}")
        
        return results

    def get_directory_tree(self, path: Path, prefix: str = "") -> str:
        """生成目录结构的树形文本

        Args:
            path: 目录路径
            prefix: 递归前缀（内部使用）

        Returns:
            str: 目录树形文本
        """
        if not path.is_dir():
            return ""

        entries = []
        for entry in sorted(path.iterdir()):
            # 跳过隐藏文件和 __pycache__
            if entry.name.startswith('.') or entry.name == '__pycache__':
                continue
            entries.append(entry)

        tree_lines = []
        for i, entry in enumerate(entries):
            is_last = (i == len(entries) - 1)
            connector = "└── " if is_last else "├── "
            child_prefix = prefix + ("    " if is_last else "│   ")

            if entry.is_dir():
                tree_lines.append(f"{prefix}{connector}📁 {entry.name}/")
                tree_lines.append(self.get_directory_tree(entry, child_prefix))
            else:
                tree_lines.append(f"{prefix}{connector}📄 {entry.name}")

        return '\n'.join(tree_lines)

    def detect_main_program(self, abap_files: List[ABAPFile], dir_path: Path) -> Optional[ABAPFile]:
        """从文件列表中识别主程序

        策略：
        1. 包含 REPORT/PROGRAM 声明且包含 INCLUDE 语句的文件 → 主程序
        2. 包含 REPORT/PROGRAM 声明的文件 → 主程序
        3. 文件名包含目录名（去掉扩展名后匹配）→ 主程序
        4. 文件列表中最大的文件 → 主程序

        Args:
            abap_files: ABAP文件列表
            dir_path: 目录路径

        Returns:
            Optional[ABAPFile]: 主程序文件
        """
        if not abap_files:
            return None

        candidates_with_include = []
        candidates_report = []

        for f in abap_files:
            lines = f.content.split('\n')[:50]
            has_report = any(re.search(r'^\s*REPORT\s+', l, re.IGNORECASE) for l in lines)
            has_program = any(re.search(r'^\s*PROGRAM\s+', l, re.IGNORECASE) for l in lines)
            has_include = any(re.search(r'^\s*INCLUDE\s+', l, re.IGNORECASE) for l in f.content.split('\n'))

            if (has_report or has_program) and has_include:
                candidates_with_include.append(f)
            elif has_report or has_program:
                candidates_report.append(f)

        # 优先：REPORT/PROGRAM + INCLUDE
        if candidates_with_include:
            return candidates_with_include[0]

        # 其次：REPORT/PROGRAM
        if candidates_report:
            return candidates_report[0]

        # 再次：文件名匹配目录名
        dir_stem = dir_path.stem.upper().rstrip('.ZIP')
        for f in abap_files:
            if f.file_name.upper().startswith(dir_stem):
                return f

        # 最后：最大的文件
        return max(abap_files, key=lambda f: f.size)

    def detect_program_pool(self, abap_files: List[ABAPFile]) -> Optional[ABAPFile]:
        """识别程序池（Program Pool）：INCLUDE 了所有其他程序文件的文件

        程序池是目录结构的最顶层文件，它通过 INCLUDE 语句包含了目录中所有其他文件。
        程序池可能与主程序（REPORT声明所在的文件）是同一个，也可能是不同的文件。

        策略：
        1. 扫描每个文件中的 INCLUDE 语句
        2. 统计每个文件 INCLUDE 了多少个目录中的其他文件
        3. INCLUDE 数量最多且覆盖率 ≥ 80% 的文件 → 程序池
        4. 如果主程序本身就是程序池，直接返回主程序
        5. 兜底：如果所有文件都不满足覆盖率，选 INCLUDE 数量最多的

        Args:
            abap_files: ABAP文件列表

        Returns:
            Optional[ABAPFile]: 程序池文件
        """
        if len(abap_files) <= 1:
            return abap_files[0] if abap_files else None

        # 建立文件名集合（不含扩展名的小写形式，用于匹配 INCLUDE 语句）
        file_name_set = set()
        file_name_full_set = set()
        for f in abap_files:
            stem = Path(f.file_name).stem.lower()
            file_name_set.add(stem)
            file_name_full_set.add(f.file_name.lower())

        other_count = len(abap_files) - 1  # 其他文件数量（不含自身）

        # 统计每个文件 INCLUDE 了多少个其他文件
        pool_candidates = []
        for f in abap_files:
            included_count = 0
            for line in f.content.split('\n'):
                inc_match = re.search(r'INCLUDE\s+(\S+)', line, re.IGNORECASE)
                if inc_match:
                    inc_name = inc_match.group(1).rstrip('.').strip()
                    inc_lower = inc_name.lower()
                    inc_stem = Path(inc_name).stem.lower() if '.' in inc_name else inc_lower

                    # 检查是否引用了目录中的其他文件
                    for other in abap_files:
                        if other.file_name.lower() == f.file_name.lower():
                            continue  # 排除自身
                        other_stem = Path(other.file_name).stem.lower()
                        other_full = other.file_name.lower()
                        if (inc_stem == other_stem or
                            inc_lower == other_full or
                            inc_stem in other_stem or
                            other_stem in inc_stem or
                            inc_lower in other_full):
                            included_count += 1
                            break  # 每个其他文件只计一次

            if included_count > 0:
                coverage = included_count / other_count if other_count > 0 else 0
                pool_candidates.append((f, included_count, coverage))

        if not pool_candidates:
            return abap_files[0]  # 兜底

        # 优先选择覆盖率 ≥ 80% 且 INCLUDE 数量最多的
        high_coverage = [(f, cnt, cov) for f, cnt, cov in pool_candidates if cov >= 0.8]
        if high_coverage:
            high_coverage.sort(key=lambda x: (-x[2], -x[1]))
            return high_coverage[0][0]

        # 否则选 INCLUDE 数量最多的
        pool_candidates.sort(key=lambda x: -x[1])
        return pool_candidates[0][0]

    def get_include_order(self, main_file: ABAPFile, abap_files: List[ABAPFile]) -> Dict[str, int]:
        """解析主程序中 INCLUDE 语句的顺序，映射到文件列表

        Args:
            main_file: 主程序文件
            abap_files: 所有ABAP文件列表

        Returns:
            Dict[str, int]: {文件名(小写): 顺序号}，0=主程序本身
        """
        order = {main_file.file_name.lower(): 0}

        # 建立文件名映射（忽略扩展名和大小写）
        file_name_map = {}
        for f in abap_files:
            # 取文件名（不含扩展名）的小写形式
            base = Path(f.file_name).stem.lower()
            full_lower = f.file_name.lower()
            file_name_map[base] = f.file_name
            file_name_map[full_lower] = f.file_name
            # 也支持文件名中间部分匹配（INCLUDE 语句中往往不带扩展名）
            file_name_map[base + f.file_path[-4:].lower()] = f.file_name  # 带扩展名

        # 解析主程序中的 INCLUDE 语句
        include_counter = 1
        for line in main_file.content.split('\n'):
            inc_match = re.search(r'INCLUDE\s+(\S+)', line, re.IGNORECASE)
            if inc_match:
                inc_name = inc_match.group(1).rstrip('.').strip()
                inc_lower = inc_name.lower()

                # 尝试匹配文件
                matched_file = None
                for key, fname in file_name_map.items():
                    if inc_lower in key.lower() or key.lower() in inc_lower:
                        matched_file = fname
                        break

                if matched_file and matched_file.lower() not in order:
                    order[matched_file.lower()] = include_counter
                    include_counter += 1

        return order
    
    def _detect_source_type(self, content: str) -> str:
        """检测代码来源类型"""
        if not content:
            return "UNKNOWN"
        
        lines = content.split('\n')[:20]
        
        # 检测报表程序
        if any(re.search(r'^\s*REPORT\s+', line, re.IGNORECASE) for line in lines):
            return "REPORT"
        
        # 检测函数模块
        if any(re.search(r'^\s*FUNCTION\s+', line, re.IGNORECASE) for line in lines):
            return "FUNCTION"
        
        # 检测类定义
        if any(re.search(r'^\s*CLASS\s+\w+\s+DEFINITION', line, re.IGNORECASE) for line in lines):
            return "CLASS"
        
        # 检测模块池
        if any(re.search(r'^\s*PROGRAM\s+', line, re.IGNORECASE) for line in lines):
            return "MODULE_POOL"
        
        # 检测包含程序
        if any(re.search(r'^\s*INCLUDE\s+', line, re.IGNORECASE) for line in lines):
            return "INCLUDE"
        
        # 检测CDS视图（DDL）
        if any(re.search(r'@AbapCatalog\.', line) or re.search(r'^\s*DEFINE\s+VIEW\s+', line, re.IGNORECASE) for line in lines):
            return "CDS"
        
        # 检测AMDP
        if any(re.search(r'^\s*METHOD\s+\w+\s+BY\s+DATABASE\s+PROCEDURE', line, re.IGNORECASE) for line in lines):
            return "AMDP"
        
        # 默认检测是否包含ABAP关键字
        abap_keywords = ['SELECT', 'DATA:', 'TYPES:', 'FORM ', 'ENDFORM', 'WRITE:', 'LOOP AT',
                        'IF ', 'ENDIF', 'CALL FUNCTION', 'PERFORM', 'TABLES:', 'PARAMETERS:',
                        'SELECT-OPTIONS:', 'START-OF-SELECTION', 'END-OF-SELECTION',
                        'INITIALIZATION', 'AT SELECTION-SCREEN', 'TOP-OF-PAGE']
        keyword_count = sum(1 for line in lines 
                          for kw in abap_keywords 
                          if re.search(r'\b' + re.escape(kw) + r'\b', line, re.IGNORECASE))
        
        if keyword_count >= 2:
            return "ABAP_GENERIC"
        
        return "UNKNOWN"
    
    def cleanup(self):
        """清理临时文件"""
        for f in self.extracted_files:
            try:
                if f.exists():
                    f.unlink()
            except Exception:
                pass
        self.extracted_files.clear()
