#!/usr/bin/env python3
"""
ABAP Business Analysis & Explanation - Analyzer
ABAPABAP_Bus_An_Exp：业务逻辑分析 - ABAP_Bus_An_Exp：业务逻辑分析引擎
负责整体ABAP_Bus_An_Exp：业务逻辑分析、行级代码说明、代码块结构识别

Author: 吴平
联系方式: 13574840501 | 微信号：wuping800223
Date: 2026-04-22
Version: 1.0.0
"""

import re
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Tuple
from pathlib import Path
from datetime import datetime


# ============================================================
# 数据结构定义
# ============================================================

@dataclass
class CodeAnnotation:
    """代码注释条目"""
    line_number: int          # 行号（1-based）
    original_code: str        # 原始代码行
    explanation: str          # 业务说明文字
    block_type: str = ""      # 所属代码块类型（LOOP/IF/WHILE/FORM等）
    block_context: str = ""   # 代码块上下文说明
    is_block_start: bool = False   # 是否为代码块开始行
    is_block_end: bool = False     # 是否为代码块结束行
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class BusinessAnalysisResult:
    """业务逻辑深度分析结果"""
    program_position: str = ""       # 程序定位（一句话描述）
    business_domain: str = ""        # 涉及的业务领域
    functional_modules: List[str] = field(default_factory=list)  # 功能模块列表
    key_tables_desc: str = ""        # 关键业务表说明
    technical_features: str = ""     # 技术特征总结


@dataclass
class FileAnalysisResult:
    """目录模式下单个文件的分析结果"""
    file_name: str               # 文件名
    file_path: str               # 文件路径
    source_type: str             # 代码来源类型
    total_lines: int             # 代码行数
    annotations: List[CodeAnnotation] = field(default_factory=list)
    overall_logic: str = ""      # 该文件的整体逻辑分析
    block_summary: Dict = field(default_factory=dict)
    table_refs: List[str] = field(default_factory=list)
    function_refs: List[str] = field(default_factory=list)
    program_refs: List[str] = field(default_factory=list)
    business_analysis: Optional['BusinessAnalysisResult'] = None
    include_order: int = 0       # 在主程序中被 INCLUDE 的顺序（0=主程序本身）


@dataclass
class AnalysisReport:
    """ABAP_Bus_An_Exp：业务逻辑分析报告"""
    file_name: str
    file_path: str
    timestamp: str
    total_lines: int
    source_type: str = "UNKNOWN"
    annotations: List[CodeAnnotation] = field(default_factory=list)
    overall_logic: str = ""    # 整体ABAP_Bus_An_Exp：业务逻辑分析文本
    block_summary: Dict = field(default_factory=dict)  # 代码块统计
    table_refs: List[str] = field(default_factory=list)  # 引用的数据库表
    function_refs: List[str] = field(default_factory=list)  # 调用的函数模块
    program_refs: List[str] = field(default_factory=list)  # 调用的程序
    user_hints: List[str] = field(default_factory=list)  # 用户提供的提示信息
    business_analysis: Optional['BusinessAnalysisResult'] = None  # 业务逻辑深度分析

    # ---- 目录模式专属字段 ----
    directory_mode: bool = False             # 是否为目录模式
    directory_tree: str = ""                  # 目录结构树文本
    main_program: str = ""                    # 主程序文件名
    program_pool: str = ""                    # 程序池文件名（INCLUDE所有其他程序的文件）
    file_results: List[FileAnalysisResult] = field(default_factory=list)  # 各文件独立分析结果


# ============================================================
# 代码块识别器
# ============================================================

# 代码块开始关键字（不区分大小写）
BLOCK_STARTS = {
    'LOOP': re.compile(r'^(\s*)(LOOP\s+AT\s+)', re.IGNORECASE),
    'IF': re.compile(r'^(\s*)(IF\s+)', re.IGNORECASE),
    'WHILE': re.compile(r'^(\s*)(WHILE\s+)', re.IGNORECASE),
    'CASE': re.compile(r'^(\s*)(CASE\s+)', re.IGNORECASE),
    'DO': re.compile(r'^(\s*)(DO\s*)', re.IGNORECASE),
    'FORM': re.compile(r'^(\s*)(FORM\s+)', re.IGNORECASE),
    'FUNCTION': re.compile(r'^(\s*)(FUNCTION\s+)', re.IGNORECASE),
    'METHOD': re.compile(r'^(\s*)(METHOD\s+)', re.IGNORECASE),
    'CLASS_DEF': re.compile(r'^(\s*)(CLASS\s+\w+\s+DEFINITION)', re.IGNORECASE),
    'CLASS_IMP': re.compile(r'^(\s*)(CLASS\s+\w+\s+IMPLEMENTATION)', re.IGNORECASE),
    'TRY': re.compile(r'^(\s*)(TRY\s*)', re.IGNORECASE),
    'SELECT_LOOP': re.compile(r'^(\s*)(SELECT\s+.*?)(\s+INTO\s)', re.IGNORECASE),
    'PROVIDE': re.compile(r'^(\s*)(PROVIDE\s+)', re.IGNORECASE),
}

# 代码块结束关键字
BLOCK_ENDS = {
    'ENDLOOP': ('LOOP', re.compile(r'^(\s*)(ENDLOOP\s*\.)', re.IGNORECASE)),
    'ENDIF': ('IF', re.compile(r'^(\s*)(ENDIF\s*\.)', re.IGNORECASE)),
    'ENDWHILE': ('WHILE', re.compile(r'^(\s*)(ENDWHILE\s*\.)', re.IGNORECASE)),
    'ENDCASE': ('CASE', re.compile(r'^(\s*)(ENDCASE\s*\.)', re.IGNORECASE)),
    'ENDDO': ('DO', re.compile(r'^(\s*)(ENDDO\s*\.)', re.IGNORECASE)),
    'ENDFORM': ('FORM', re.compile(r'^(\s*)(ENDFORM\s*\.)', re.IGNORECASE)),
    'ENDFUNCTION': ('FUNCTION', re.compile(r'^(\s*)(ENDFUNCTION\s*\.)', re.IGNORECASE)),
    'ENDMETHOD': ('METHOD', re.compile(r'^(\s*)(ENDMETHOD\s*\.)', re.IGNORECASE)),
    'ENDCLASS': ('CLASS', re.compile(r'^(\s*)(ENDCLASS\s*\.)', re.IGNORECASE)),
    'ENDTRY': ('TRY', re.compile(r'^(\s*)(ENDTRY\s*\.)', re.IGNORECASE)),
    'ENDSELECT': ('SELECT_LOOP', re.compile(r'^(\s*)(ENDSELECT\s*\.)', re.IGNORECASE)),
    'ENDPROVIDE': ('PROVIDE', re.compile(r'^(\s*)(ENDPROVIDE\s*\.)', re.IGNORECASE)),
}

# ABAP结构定义关键字（BEGIN OF ... END OF）
# 注意：不加 ^ 锚点，因为 DATA:/TYPES: 等前缀会出现在 BEGIN OF 之前
STRUCT_START = re.compile(r'BEGIN\s+OF\s+', re.IGNORECASE)
STRUCT_END = re.compile(r'END\s+OF\s+', re.IGNORECASE)

# 数据库表引用模式
TABLE_REF_PATTERNS = [
    re.compile(r'(?:FROM|INTO|UPDATING|MODIFYING)\s+(\w+)', re.IGNORECASE),
    re.compile(r'TABLES:\s*(\w+)', re.IGNORECASE),
    re.compile(r'(?:JOIN|INNER JOIN|LEFT JOIN|RIGHT JOIN)\s+(\w+)', re.IGNORECASE),
]

# 函数模块调用模式
FUNC_CALL_PATTERN = re.compile(r"CALL\s+FUNCTION\s+'(\S+)'", re.IGNORECASE)

# 程序调用模式
PROG_CALL_PATTERN = re.compile(r'SUBMIT\s+(\w+)', re.IGNORECASE)

# ABAP关键字集合（用于行级分析）
ABAP_KEYWORDS = {
    'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'MODIFY', 'INTO', 'FROM', 'WHERE',
    'LOOP', 'AT', 'ENDLOOP', 'IF', 'ELSE', 'ELSEIF', 'ENDIF', 'WHILE', 'ENDWHILE',
    'CASE', 'WHEN', 'ENDCASE', 'DO', 'ENDDO', 'FORM', 'ENDFORM', 'PERFORM',
    'FUNCTION', 'ENDFUNCTION', 'METHOD', 'ENDMETHOD', 'CLASS', 'ENDCLASS',
    'DATA', 'TYPES', 'CONSTANTS', 'STATICS', 'FIELD-SYMBOLS',
    'TABLES', 'PARAMETERS', 'SELECT-OPTIONS', 'RANGES',
    'WRITE', 'ULINE', 'SKIP', 'NEW-PAGE', 'NEW-LINE',
    'CALL', 'SUBMIT', 'LEAVE', 'EXIT', 'RETURN', 'CONTINUE', 'CHECK',
    'CLEAR', 'REFRESH', 'FREE', 'MOVE', 'COMPUTE', 'ADD', 'SUBTRACT',
    'CONCATENATE', 'SPLIT', 'SHIFT', 'CONVERT', 'TRANSLATE', 'REPLACE',
    'APPEND', 'COLLECT', 'INSERT', 'DELETE', 'MODIFY', 'READ', 'SORT',
    'DESCRIBE', 'LOOP', 'MESSAGE', 'AUTHORITY-CHECK',
    'START-OF-SELECTION', 'END-OF-SELECTION', 'INITIALIZATION',
    'TOP-OF-PAGE', 'END-OF-PAGE', 'AT LINE-SELECTION', 'AT USER-COMMAND',
    'AT SELECTION-SCREEN', 'AT PF', 'TRY', 'CATCH', 'CLEANUP', 'ENDTRY',
    'CREATE OBJECT', 'RAISE EVENT', 'SET HANDLER',
    'BEGIN OF', 'END OF', 'OCCURS', 'WITH HEADER LINE',
    'INNER JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'FULL JOIN',
    'GROUP BY', 'ORDER BY', 'HAVING', 'DISTINCT',
    'BAPÍCALL', 'REUSE_', 'GUI_',
}

# 常见SAP表名及其中文含义
SAP_TABLES = {
    'MARA': '物料主数据（基本视图）', 'MAKT': '物料描述', 'MARD': '物料库存（仓储位置视图）',
    'MSEG': '物料凭证段', 'MKPF': '物料凭证抬头', 'EKPO': '采购订单项',
    'EKKO': '采购订单抬头', 'LFA1': '供应商主数据（一般段）', 'LFB1': '供应商主数据（公司代码段）',
    'KNA1': '客户主数据（一般段）', 'KNB1': '客户主数据（公司代码段）', 'VBAK': '销售订单抬头',
    'VBAP': '销售订单项', 'VBFA': '销售凭证流', 'BSEG': '会计凭证段',
    'BKPF': '会计凭证抬头', 'SKAT': '总账科目描述', 'T001': '公司代码',
    'T001W': '工厂/分支', 'T024': '采购组', 'T001L': '仓储位置',
    'BSIS': '未清G/L行项目', 'BSAS': '已清G/L行项目', 'BSIK': '未清供应商行项目',
    'BSAK': '已清供应商行项目', 'BSID': '未清客户行项目', 'BSAD': '已清客户行项目',
    'LIPS': '交货项', 'LIKP': '交货抬头', 'VBAK': '销售凭证抬头',
    'VBAP': '销售凭证项', 'AUFK': '订单抬头', 'AFKO': '订单头数据',
    'AFPO': '订单项数据', 'RESB': '预订', 'PLAF': '计划订单',
    'JEST': '单个对象状态', 'TJ02T': '状态文本', 'TSTC': '事务代码表',
    'USR01': '用户主数据', 'USR02': '用户登录数据', 'AGR_USERS': '角色用户分配',
    'TADIR': '目录条目（开发对象）', 'TRDIR': '程序目录', 'DD03L': '表字段',
    'DD02L': 'ABAP字典：表', 'DD02T': '表文本', 'DD03T': '字段文本',
    'SFLIGHT': '航班模型表', 'SPFLI': '航线模型表', 'SCUSTOM': '客户模型表',
    'SBOOK': '预订模型表', 'STPO': 'BOM项', 'STKO': 'BOM抬头',
    'CSKT': '成本中心描述', 'COBK': 'CO凭证抬头', 'COEP': 'CO凭证行项目',
}

# 常见ABAP关键字中文说明
KEYWORD_MEANINGS = {
    'REPORT': '定义报表程序', 'PROGRAM': '定义程序', 'DATA': '定义数据对象/变量',
    'TYPES': '定义数据类型', 'CONSTANTS': '定义常量', 'STATICS': '定义静态变量',
    'FIELD-SYMBOLS': '定义字段符号（指针）', 'TABLES': '声明数据库表工作区',
    'PARAMETERS': '定义选择屏幕参数', 'SELECT-OPTIONS': '定义选择屏幕范围',
    'SELECT': '数据库查询', 'INSERT': '数据库插入', 'UPDATE': '数据库更新',
    'DELETE': '数据库删除', 'MODIFY': '数据库修改', 'INTO': '数据存入目标',
    'FROM': '数据来源', 'WHERE': '查询条件', 'LOOP AT': '循环遍历内表',
    'APPEND': '追加行到内表', 'COLLECT': '按唯一键汇总到内表', 'INSERT INTO': '插入行到内表',
    'MODIFY': '修改内表行', 'DELETE': '删除内表行', 'READ TABLE': '读取内表行',
    'SORT': '排序内表', 'DESCRIBE TABLE': '获取内表属性',
    'IF': '条件判断开始', 'ELSE': '条件不满足时', 'ELSEIF': '额外条件判断',
    'ENDIF': '条件判断结束', 'CASE': '多分支判断', 'WHEN': '分支条件',
    'ENDCASE': '多分支判断结束', 'WHILE': '条件循环', 'ENDWHILE': '条件循环结束',
    'DO': '计数循环', 'ENDDO': '计数循环结束', 'FORM': '定义子程序/宏',
    'ENDFORM': '子程序结束', 'PERFORM': '调用子程序', 'FUNCTION': '定义函数模块',
    'CALL FUNCTION': '调用函数模块', 'METHOD': '定义方法', 'CALL METHOD': '调用方法',
    'WRITE': '输出到列表', 'ULINE': '画下划线', 'SKIP': '跳过行',
    'MESSAGE': '输出消息', 'CLEAR': '清空变量/字段', 'REFRESH': '清空内表',
    'FREE': '释放内存', 'MOVE': '赋值', 'CONCATENATE': '字符串拼接',
    'SPLIT': '字符串拆分', 'SHIFT': '字符串移位', 'TRANSLATE': '大小写转换',
    'REPLACE': '字符串替换', 'CONVERT': '数据格式转换',
    'SUBMIT': '调用另一个报表程序', 'LEAVE TO TRANSACTION': '跳转到事务代码',
    'LEAVE PROGRAM': '退出程序', 'EXIT': '退出当前循环/处理块',
    'RETURN': '返回调用处', 'CONTINUE': '跳过当前循环迭代',
    'CHECK': '条件检查，不满足则跳过', 'TRY': '异常处理开始', 'CATCH': '捕获异常',
    'CLEANUP': '异常清理', 'ENDTRY': '异常处理结束',
    'START-OF-SELECTION': '事件：选择开始后执行', 'END-OF-SELECTION': '事件：列表输出前执行',
    'INITIALIZATION': '事件：选择屏幕初始化', 'TOP-OF-PAGE': '事件：每页页头',
    'AT SELECTION-SCREEN': '事件：选择屏幕处理',
    'CLASS': '定义类', 'CREATE OBJECT': '创建对象实例',
    'BEGIN OF': '结构体/内表开始', 'END OF': '结构体/内表结束',
    'OCCURS': '定义内表初始行数', 'WITH HEADER LINE': '带表头行',
    'INNER JOIN': '内连接', 'LEFT JOIN': '左外连接', 'RIGHT JOIN': '右外连接',
    'GROUP BY': '分组', 'ORDER BY': '排序', 'HAVING': '分组后过滤',
    'DISTINCT': '去重',
}


# ============================================================
# 分析引擎
# ============================================================

class ABAPBusinessAnalyzer:
    """ABAPABAP_Bus_An_Exp：业务逻辑分析引擎"""
    
    def __init__(self):
        self.block_stack: List[Dict] = []  # 代码块栈，用于跟踪嵌套结构
    
    def analyze(self, abap_file, user_hints: List[str] = None) -> AnalysisReport:
        """分析ABAP文件，生成业务逻辑报告
        
        Args:
            abap_file: ABAPFile对象
            user_hints: 用户提供的提示信息列表（用于增强ABAP_Bus_An_Exp：业务逻辑分析）
            
        Returns:
            AnalysisReport: 分析报告
        """
        lines = abap_file.content.split('\n')
        self.block_stack = []
        
        # 第一遍：识别代码块结构
        block_map = self._identify_blocks(lines)
        
        # 第二遍：提取数据库表引用（区分确认表和不确定对象）
        table_refs, uncertain_refs = self._extract_table_refs(lines)
        
        # 第三遍：提取函数模块调用
        function_refs = self._extract_function_refs(lines)
        
        # 第四遍：提取程序调用
        program_refs = self._extract_program_refs(lines)
        
        # 第五遍：生成整体ABAP_Bus_An_Exp：业务逻辑分析（含用户提示）
        overall_logic = self._analyze_overall_logic(
            lines, abap_file.source_type, table_refs, function_refs, program_refs,
            user_hints=user_hints or [], uncertain_refs=uncertain_refs or []
        )
        
        # 提取子程序和方法名（供深度分析使用）
        form_names = [m.group(1).rstrip('.') for m in 
                      [re.search(r'FORM\s+(\S+)', line, re.IGNORECASE) for line in lines] if m]
        events_found = []
        event_patterns = [
            ('START-OF-SELECTION', '选择开始事件'),
            ('END-OF-SELECTION', '选择结束事件'),
            ('INITIALIZATION', '初始化事件'),
            ('TOP-OF-PAGE', '页头事件'),
            ('AT SELECTION-SCREEN', '选择屏幕事件'),
            ('AT LINE-SELECTION', '行选择事件'),
            ('AT USER-COMMAND', '用户命令事件'),
        ]
        for pattern, desc in event_patterns:
            if any(re.search(pattern, line, re.IGNORECASE) for line in lines):
                events_found.append(desc)
        
        # 第六遍：生成逐行代码说明
        annotations = self._generate_line_annotations(lines, block_map, table_refs)
        
        # 第七遍：生成业务逻辑深度分析（基于代码结构自动推断）
        business_analysis = self._analyze_business_deep(
            lines, abap_file.source_type, table_refs, function_refs, program_refs,
            form_names, events_found, user_hints=user_hints or []
        )
        
        # 代码块统计
        block_summary = self._compute_block_summary(block_map)
        
        return AnalysisReport(
            file_name=abap_file.file_name,
            file_path=abap_file.file_path,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            total_lines=len(lines),
            source_type=abap_file.source_type,
            annotations=annotations,
            overall_logic=overall_logic,
            block_summary=block_summary,
            table_refs=table_refs,
            function_refs=function_refs,
            program_refs=program_refs,
            user_hints=user_hints or [],
            business_analysis=business_analysis
        )

    def analyze_directory(self, abap_files: List, dir_path: str, user_hints: List[str] = None) -> AnalysisReport:
        """分析目录下的多个ABAP文件

        流程：
        1. 生成目录树
        2. 识别主程序
        3. 解析主程序中 INCLUDE 顺序
        4. 按顺序分析每个文件（主程序→INCLUDE #1→INCLUDE #2→...→未引用文件）
        5. 汇总生成合并报告

        Args:
            abap_files: ABAPFile 对象列表
            dir_path: 目录路径字符串
            user_hints: 用户提示信息列表

        Returns:
            AnalysisReport: 合并分析报告
        """
        from pathlib import Path as P
        from frm_bae_file_handler import FileHandler

        dir_p = P(dir_path)
        handler = FileHandler()

        # 1. 生成目录树
        dir_tree = handler.get_directory_tree(dir_p)

        # 2. 识别主程序
        main_file = handler.detect_main_program(abap_files, dir_p)
        main_name = main_file.file_name if main_file else ""
        print(f"  📋 识别主程序: {main_name}")

        # 3. 解析 INCLUDE 顺序
        if main_file:
            include_order = handler.get_include_order(main_file, abap_files)
            ordered_names = sorted(include_order.keys(), key=lambda x: include_order[x])
        else:
            include_order = {}
            ordered_names = [f.file_name.lower() for f in abap_files]

        # 4. 建立 文件名→ABAPFile 映射
        file_map = {f.file_name.lower(): f for f in abap_files}

        # 5. 按顺序分析每个文件
        file_results: List[FileAnalysisResult] = []
        all_annotations = []
        all_table_refs = []
        all_function_refs = []
        all_program_refs = []
        total_lines = 0

        for idx, fname_lower in enumerate(ordered_names):
            af = file_map.get(fname_lower)
            if not af:
                continue

            print(f"  🔍 分析 [{idx}]: {af.file_name}...")
            try:
                report = self.analyze(af, user_hints=user_hints)

                fr = FileAnalysisResult(
                    file_name=af.file_name,
                    file_path=af.file_path,
                    source_type=report.source_type,
                    total_lines=report.total_lines,
                    annotations=report.annotations,
                    overall_logic=report.overall_logic,
                    block_summary=report.block_summary,
                    table_refs=report.table_refs,
                    function_refs=report.function_refs,
                    program_refs=report.program_refs,
                    business_analysis=report.business_analysis,
                    include_order=include_order.get(fname_lower, 0)
                )
                file_results.append(fr)

                all_annotations.extend(report.annotations)
                total_lines += report.total_lines
                all_table_refs.extend(report.table_refs)
                all_function_refs.extend(report.function_refs)
                all_program_refs.extend(report.program_refs)

            except Exception as e:
                print(f"  ⚠️ 分析 {af.file_name} 出错: {e}")

        # 6. 对未在 INCLUDE 顺序中的文件，追加到末尾
        analyzed_names = set(ordered_names)
        remaining = [f for f in abap_files if f.file_name.lower() not in analyzed_names]
        for af in remaining:
            print(f"  🔍 分析 [附加]: {af.file_name}...")
            try:
                report = self.analyze(af, user_hints=user_hints)
                fr = FileAnalysisResult(
                    file_name=af.file_name,
                    file_path=af.file_path,
                    source_type=report.source_type,
                    total_lines=report.total_lines,
                    annotations=report.annotations,
                    overall_logic=report.overall_logic,
                    block_summary=report.block_summary,
                    table_refs=report.table_refs,
                    function_refs=report.function_refs,
                    program_refs=report.program_refs,
                    business_analysis=report.business_analysis,
                    include_order=999
                )
                file_results.append(fr)
                all_annotations.extend(report.annotations)
                total_lines += report.total_lines
                all_table_refs.extend(report.table_refs)
                all_function_refs.extend(report.function_refs)
                all_program_refs.extend(report.program_refs)
            except Exception as e:
                print(f"  ⚠️ 分析 {af.file_name} 出错: {e}")

        # 7. 汇总整体逻辑
        overall_parts = []
        if main_name:
            overall_parts.append(f"主程序: {main_name}")
        overall_parts.append(f"文件数量: {len(file_results)}")
        overall_parts.append(f"代码总行数: {total_lines}")
        if all_table_refs:
            unique_tables = list(dict.fromkeys(all_table_refs))[:10]
            overall_parts.append(f"涉及数据表 ({len(unique_tables)}): {', '.join(unique_tables)}")
        if all_function_refs:
            unique_funcs = list(dict.fromkeys(all_function_refs))[:10]
            overall_parts.append(f"调用函数模块 ({len(unique_funcs)}): {', '.join(unique_funcs)}")
        overall_logic = '\n'.join(overall_parts)

        # 8. 构建合并报告
        # 对主程序文件做深度分析
        main_report = None
        if main_file:
            try:
                main_report = self.analyze(main_file, user_hints=user_hints)
            except Exception:
                pass

        merged = AnalysisReport(
            file_name=dir_p.name,
            file_path=str(dir_p.resolve()),
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            total_lines=total_lines,
            source_type="DIRECTORY",
            annotations=all_annotations,
            overall_logic=overall_logic,
            table_refs=list(dict.fromkeys(all_table_refs)),
            function_refs=list(dict.fromkeys(all_function_refs)),
            program_refs=list(dict.fromkeys(all_program_refs)),
            user_hints=user_hints or [],
            business_analysis=main_report.business_analysis if main_report else None,
            directory_mode=True,
            directory_tree=dir_tree,
            main_program=main_name,
            file_results=file_results
        )
        return merged

    def _identify_blocks(self, lines: List[str]) -> Dict[int, Dict]:
        """识别代码块结构，返回 {行号: {type, action, context}} 映射"""
        block_map = {}
        struct_stack = []  # BEGIN OF ... END OF 栈
        
        for i, line in enumerate(lines):
            stripped = line.strip()
            upper = stripped.upper()
            line_no = i + 1  # 1-based
            
            # 检查 BEGIN OF ... END OF 结构
            struct_match = STRUCT_START.search(stripped)
            if struct_match:
                # 提取结构体名称
                struct_name = self._extract_struct_name(stripped)
                struct_stack.append({
                    'name': struct_name,
                    'start': line_no,
                    'line': stripped
                })
                block_map[line_no] = {
                    'type': 'BEGIN_OF',
                    'action': 'start',
                    'context': f'定义结构体/内表 "{struct_name}" 的开始'
                }
                continue
            
            struct_end_match = STRUCT_END.search(stripped)
            if struct_end_match and struct_stack:
                struct_info = struct_stack.pop()
                block_map[line_no] = {
                    'type': 'END_OF',
                    'action': 'end',
                    'context': f'结构体/内表 "{struct_info["name"]}" 定义结束'
                }
                continue
            
            # 检查代码块开始
            for block_name, pattern in BLOCK_STARTS.items():
                match = pattern.search(stripped)
                if match:
                    context = self._get_block_context(block_name, stripped)
                    self.block_stack.append({
                        'type': block_name,
                        'start': line_no,
                        'context': context,
                        'line': stripped
                    })
                    block_map[line_no] = {
                        'type': block_name,
                        'action': 'start',
                        'context': context
                    }
                    break
            else:
                # 检查代码块结束
                for end_name, (start_type, pattern) in BLOCK_ENDS.items():
                    match = pattern.search(stripped)
                    if match:
                        # 从栈中找到对应的开始
                        start_info = None
                        for j in range(len(self.block_stack) - 1, -1, -1):
                            if self.block_stack[j]['type'] == start_type:
                                start_info = self.block_stack.pop(j)
                                break
                        
                        context = start_info['context'] if start_info else f'{start_type} 块结束'
                        block_map[line_no] = {
                            'type': start_type,
                            'action': 'end',
                            'context': context
                        }
                        break
        
        return block_map
    
    def _extract_struct_name(self, line: str) -> str:
        """从 BEGIN OF 行提取结构体名称"""
        # 匹配各种形式：
        # DATA: BEGIN OF lt_mara OCCURS 0,
        # TYPES: BEGIN OF ty_header.
        # DATA BEGIN OF ls_header.
        match = re.search(r'BEGIN\s+OF\s+(\S+)', line, re.IGNORECASE)
        if match:
            name = match.group(1).rstrip(',.')
            return name
        return "<匿名结构>"
    
    def _get_block_context(self, block_type: str, line: str) -> str:
        """获取代码块的上下文说明"""
        upper = line.upper().strip()
        
        if block_type == 'LOOP':
            # LOOP AT lt_ekpo INTO ls_ekpo.
            match = re.search(r'LOOP\s+AT\s+(\S+)', upper)
            if match:
                table_name = match.group(1).rstrip('.')
                into_match = re.search(r'INTO\s+(\S+)', upper)
                wa = into_match.group(1).rstrip('.') if into_match else ""
                return f'循环遍历内表 {table_name}' + (f"，每行数据放入工作区 {wa}" if wa else "")
        
        elif block_type == 'IF':
            cond = re.sub(r'^\s*IF\s+', '', upper, flags=re.IGNORECASE).rstrip('.')
            return f'条件判断: {cond}'
        
        elif block_type == 'WHILE':
            cond = re.sub(r'^\s*WHILE\s+', '', upper, flags=re.IGNORECASE).rstrip('.')
            return f'条件循环: {cond}'
        
        elif block_type == 'CASE':
            var = re.sub(r'^\s*CASE\s+', '', upper, flags=re.IGNORECASE).rstrip('.')
            return f'多分支判断，判断变量: {var}'
        
        elif block_type == 'DO':
            times_match = re.search(r'DO\s+(\d+)\s+TIMES', upper)
            if times_match:
                return f'固定次数循环: {times_match.group(1)} 次'
            return '不定次数循环（DO）'
        
        elif block_type == 'FORM':
            match = re.search(r'FORM\s+(\S+)', upper)
            name = match.group(1) if match else "<匿名>"
            return f'子程序 {name} 定义开始'
        
        elif block_type == 'FUNCTION':
            match = re.search(r'FUNCTION\s+(\S+)', upper)
            name = match.group(1) if match else "<匿名>"
            return f'函数模块 {name} 定义开始'
        
        elif block_type == 'METHOD':
            match = re.search(r'METHOD\s+(\S+)', upper)
            name = match.group(1) if match else "<匿名>"
            return f'方法 {name} 定义开始'
        
        elif block_type == 'CLASS_DEF':
            match = re.search(r'CLASS\s+(\S+)\s+DEFINITION', upper)
            name = match.group(1) if match else "<匿名>"
            return f'类 {name} 的定义部分开始'
        
        elif block_type == 'CLASS_IMP':
            match = re.search(r'CLASS\s+(\S+)\s+IMPLEMENTATION', upper)
            name = match.group(1) if match else "<匿名>"
            return f'类 {name} 的实现部分开始'
        
        elif block_type == 'TRY':
            return '异常处理块（TRY）开始'
        
        elif block_type == 'SELECT_LOOP':
            # SELECT ... ENDSELECT 形式
            from_match = re.search(r'FROM\s+(\S+)', upper)
            table_name = from_match.group(1) if from_match else ""
            into_match = re.search(r'INTO\s+(\S+)', upper)
            target = into_match.group(1) if into_match else ""
            return f'循环读取数据库表 {table_name}' + (f"，结果放入 {target}" if target else '')
        
        elif block_type == 'PROVIDE':
            return 'PROVIDE 循环块开始'
        
        return f'{block_type} 代码块开始'
    
    def _collect_local_variables(self, lines: List[str]) -> set:
        """扫描代码中所有 DATA/TYPES/FIELD-SYMBOLS/SELECT-OPTIONS/PARAMETERS 声明，
        收集所有局部变量名（包括内表、工作区、结构体、字段符号等）。
        
        这些变量不是数据库表，在提取表引用时需要排除。
        """
        local_vars = set()
        
        # --- 模式1: DATA ... BEGIN OF <name> / DATA: BEGIN OF <name> ---
        # DATA: BEGIN OF lt_mara OCCURS 0,
        # DATA BEGIN OF ls_header.
        for line in lines:
            m = re.search(r'DATA\s*:?\s*BEGIN\s+OF\s+(\S+)', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper().rstrip(','))
        
        # --- 模式2: DATA <name> TYPE|LIKE ... (包括内表、结构体、简单变量) ---
        # DATA: lt_tab TYPE TABLE OF mara.
        # DATA(lv_name) = ...
        # DATA: ls_wa TYPE mara.
        # DATA: lt_data LIKE TABLE OF t001.
        for line in lines:
            # DATA(<name>) 内联声明
            m = re.search(r'DATA\((\w+)\)', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper())
            # DATA: <name> 或 DATA <name> TYPE/LIKE
            m = re.search(r'(?:^|\s)DATA\s*:?s*\s+(\w+)\s', line, re.IGNORECASE)
            if m:
                name = m.group(1).upper().rstrip(':,')
                # 排除 ABAP 关键字（如 DATA BEGIN 中的 BEGIN）
                if name not in ('BEGIN', 'END', 'TYPE', 'LIKE', 'TABLE', 'STANDARD',
                                'SORTED', 'HASHED', 'WITH', 'HEADER', 'LINE', 'OCCURS',
                                'VALUE', 'REFERENCE', 'INITIAL'):
                    local_vars.add(name)
        
        # --- 模式3: TYPES 声明 ---
        # TYPES: BEGIN OF ty_header.
        # TYPES: ty_tab TYPE TABLE OF mara.
        for line in lines:
            m = re.search(r'TYPES\s*:?\s*BEGIN\s+OF\s+(\S+)', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper().rstrip(','))
            m = re.search(r'(?:^|\s)TYPES\s*:?s*\s+(\w+)\s', line, re.IGNORECASE)
            if m:
                name = m.group(1).upper().rstrip(':,')
                if name not in ('BEGIN', 'END', 'TYPE', 'LIKE', 'TABLE', 'STANDARD',
                                'SORTED', 'HASHED', 'WITH', 'HEADER', 'LINE', 'OCCURS',
                                'VALUE', 'REFERENCE', 'INITIAL', 'RANGE', 'REF', 'TO'):
                    local_vars.add(name)
        
        # --- 模式4: FIELD-SYMBOLS ---
        # FIELD-SYMBOLS: <fs_line> TYPE ANY TABLE.
        for line in lines:
            m = re.search(r'FIELD-SYMBOLS\s*:?\s*<(\S+)>', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper())
        
        # --- 模式5: SELECT-OPTIONS / PARAMETERS（这些不是表，是选择屏幕变量） ---
        # SELECT-OPTIONS: s_matnr FOR mara-matnr.
        # PARAMETERS: p_bukrs TYPE t001-bukrs.
        for line in lines:
            m = re.search(r'SELECT-OPTIONS\s*:?s*\s+(\w+)', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper().rstrip(':'))
            m = re.search(r'PARAMETERS\s*:?s*\s+(\w+)', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper().rstrip(':'))
        
        # --- 模式6: RANGES（选择范围变量） ---
        # RANGES: r_date FOR sy-datum.
        for line in lines:
            m = re.search(r'RANGES\s*:?s*\s+(\w+)', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper().rstrip(':'))
        
        # --- 模式7: STATICS ---
        # STATICS: lv_counter TYPE i.
        for line in lines:
            m = re.search(r'STATICS\s*:?s*\s+(\w+)', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper().rstrip(':'))
        
        # --- 模式8: CONSTANTS ---
        # CONSTANTS: lc_value TYPE c LENGTH 1 VALUE 'X'.
        for line in lines:
            m = re.search(r'CONSTANTS\s*:?s*\s+(\w+)', line, re.IGNORECASE)
            if m:
                local_vars.add(m.group(1).upper().rstrip(':'))
        
        # --- 模式9: 从 LOOP AT / SORT / READ TABLE / APPEND / MODIFY / DELETE / COLLECT
        # 等内表操作语句中推断内表名（变量可能定义在 INCLUDE 文件中，当前代码扫描不到声明） ---
        # LOOP AT <itab> INTO <wa> / SORT <itab> / READ TABLE <itab> / APPEND <wa> TO <itab>
        # MODIFY <itab> FROM <wa> / DELETE <itab> WHERE / COLLECT <wa> INTO <itab>
        # DELETE ADJACENT DUPLICATES FROM <itab> / REFRESH <itab> / CLEAR <itab>
        itab_patterns = [
            (r'LOOP\s+AT\s+(\w+)', None),                    # LOOP AT <itab>
            (r'SORT\s+(\w+)', r'SORT\s+(\w+)\s+BY'),        # SORT <itab> BY ...
            (r'READ\s+TABLE\s+(\w+)', None),                  # READ TABLE <itab>
            (r'APPEND\s+\w+\s+TO\s+(\w+)', None),             # APPEND <wa> TO <itab>
            (r'APPEND\s+INITIAL\s+LINE\s+TO\s+(\w+)', None),  # APPEND INITIAL LINE TO <itab>
            (r'APPEND\s+LINES\s+OF\s+(\w+)', None),           # APPEND LINES OF <itab>
            (r'MODIFY\s+(\w+)\s+FROM\s+', None),               # MODIFY <itab> FROM <wa>
            (r'MODIFY\s+(\w+)\s+TRANSPORTING', None),          # MODIFY <itab> TRANSPORTING ...
            (r'DELETE\s+(\w+)\s+WHERE\b', None),               # DELETE <itab> WHERE ...
            (r'DELETE\s+(\w+)\s+INDEX\b', None),               # DELETE <itab> INDEX ...
            (r'DELETE\s+ADJACENT\s+DUPLICATES\s+FROM\s+(\w+)', None),  # DELETE ADJ FROM <itab>
            (r'COLLECT\s+\w+\s+INTO\s+(\w+)', None),           # COLLECT <wa> INTO <itab>
            (r'REFRESH\s*:?s*\s*(\w+)', None),                 # REFRESH <itab>
            (r'DESCRIBE\s+TABLE\s+(\w+)', None),               # DESCRIBE TABLE <itab>
            (r'FOR\s+ALL\s+ENTRIES\s+IN\s+(\w+)', None),       # FOR ALL ENTRIES IN <itab>
            (r'INSERT\s+LINES\s+OF\s+(\w+)', None),            # INSERT LINES OF <itab>
            (r'INSERT\s+\w+\s+INTO\s+TABLE\s+(\w+)', None),    # INSERT <wa> INTO TABLE <itab>
        ]
        for line in lines:
            stripped = line.strip().upper()
            if stripped.startswith('*') or stripped.startswith('"'):
                continue
            for pattern, filter_pat in itab_patterns:
                if filter_pat and not re.search(filter_pat, line, re.IGNORECASE):
                    # 有附加过滤条件的模式（如 SORT 必须跟 BY 才是内表操作）
                    continue
                m = re.search(pattern, stripped, re.IGNORECASE)
                if m:
                    itab_name = m.group(1).upper().rstrip(',.:')
                    if itab_name not in ('TABLE', 'LINE', 'ADJACENT', 'DUPLICATES',
                                          'ALL', 'ENTRIES', 'INITIAL', 'LINES',
                                          'INTO', 'INDEX', 'WHERE', 'FROM',
                                          'OF', 'FIELDS', 'CORRESPONDING'):
                        local_vars.add(itab_name)
        
        return local_vars
    
    def _extract_table_refs(self, lines: List[str]) -> Tuple[List[str], List[str]]:
        """提取代码中引用的数据库表，区分确认表和不确定对象。
        
        核心策略：
        1. 先扫描所有 DATA/TYPES 等声明 + 内表操作语句，收集局部变量名
        2. 将多行 ABAP 语句拼接为单行（处理链式续行语法）
        3. 从拼接后的语句中提取数据库表引用
        4. TABLES: 声明区分程序级和 FORM/PERFORM 子程序参数
        5. 过滤掉局部变量，无法确认的归为 uncertain
        """
        ABAP_KW = {
            'INTO', 'WHERE', 'FROM', 'TABLE', 'INNER', 'LEFT', 'RIGHT',
            'ORDER', 'GROUP', 'HAVING', 'JOIN', 'FULL', 'APPENDING',
            'CORRESPONDING', 'FIELDS', 'CLIENT', 'UP', 'TO', 'ROWS',
            'TABLES', 'USING', 'CHANGING', 'SOURCE', 'TARGET',
            'STANDARD', 'SORTED', 'HASHED', 'INDEX', 'BINARY',
            'ALL', 'DISTINCT', 'SINGLE', 'PACKAGE', 'SIZE',
            'TIME', 'ZONE', 'STAMP', 'CONVERT', 'DATE',
        }
        
        local_vars = self._collect_local_variables(lines)
        confirmed = set()
        uncertain = set()
        
        # 拼接多行语句为单行
        joined = self._join_abap_statements(lines)
        
        # JOIN 目标（必须是数据库表）
        for stmt in joined:
            u = stmt.upper()
            if '\bJOIN\b' not in u:
                continue
            for jm in re.findall(r'JOIN\s+(\w+)', u):
                jn = jm.upper().rstrip('.')
                if jn not in ABAP_KW and jn not in local_vars:
                    confirmed.add(jn)
        
        # SELECT ... FROM
        for stmt in joined:
            u = stmt.upper()
            if '\bSELECT\b' not in u or '\bSELECT-OPTIONS\b' in u:
                continue
            if 'DELETE ADJACENT DUPLICATES' in u:
                continue
            for fm in re.findall(r'FROM\s+(\w+)', u):
                fn = fm.upper().rstrip('.')
                if fn in ABAP_KW or fn in local_vars:
                    continue
                if fn in SAP_TABLES:
                    confirmed.add(fn)
                elif re.match(r'^[YZ]', fn):
                    confirmed.add(fn)
                else:
                    uncertain.add(fn)
        
        # DML 操作数据库表
        for stmt in joined:
            u = stmt.upper()
            if 'DELETE ADJACENT DUPLICATES' in u:
                continue
            for kw in (r'MODIFY\s+(\w+)\s+FROM\s', r'UPDATE\s+(\w+)\s+SET\s',
                       r'DELETE\s+FROM\s+(\w+)', r'INSERT\s+(\w+)\s+FROM\s+'):
                m = re.search(kw, u)
                if m:
                    tn = m.group(1).upper()
                    if tn not in ABAP_KW and tn not in local_vars:
                        confirmed.add(tn)
        
        # TABLES 声明（区分程序级和子程序参数）
        selopt = {v for v in local_vars if re.match(r'^[SPR]_', v)}
        
        fp_ranges = set()
        i = 0
        while i < len(lines):
            s = lines[i].strip().upper()
            if re.match(r'^\s*FORM\s+\w+.*\bTABLES\b', s, re.IGNORECASE):
                fp_ranges.add(i)
                if not s.rstrip().endswith('.'):
                    j = i + 1
                    while j < len(lines):
                        fp_ranges.add(j)
                        if lines[j].strip().upper().rstrip().endswith('.'):
                            break
                        j += 1
            elif re.search(r'^\s*PERFORM\s+\w+\s*:', s, re.IGNORECASE):
                fp_ranges.add(i)
                j = i + 1
                while j < len(lines):
                    fp_ranges.add(j)
                    if lines[j].strip().upper().rstrip().endswith('.'):
                        break
                    j += 1
            i += 1
        
        for i, line in enumerate(lines):
            if i in fp_ranges:
                continue
            if re.search(r'^\s*TABLES\s*:', line, re.IGNORECASE):
                names = re.findall(r'TABLES\s*:\s*(.*)', line, re.IGNORECASE)
                if names:
                    for name in names[0].split(','):
                        n = name.strip().upper().rstrip('.')
                        if n and n not in ABAP_KW and n not in selopt:
                            confirmed.add(n)
            elif re.match(r'^\s*TABLES\s+(\w+)', line, re.IGNORECASE):
                m = re.match(r'^\s*TABLES\s+(\w+)', line, re.IGNORECASE)
                tn = m.group(1).upper().rstrip(':')
                if tn not in ABAP_KW and tn not in selopt:
                    confirmed.add(tn)
        
        confirmed -= local_vars
        return sorted(confirmed), sorted(uncertain)
    
    def _join_abap_statements(self, lines: List[str]) -> List[str]:
        """将多行 ABAP 语句拼接为单行（ABAP 以句点结尾）。"""
        result = []
        cur = ""
        for line in lines:
            s = line.strip()
            if s.startswith('*'):
                continue
            cp = self._strip_inline_comment(s)
            if not cp:
                continue
            cur += " " + cp
            if cur.rstrip().endswith('.'):
                result.append(cur.strip())
                cur = ""
        if cur.strip():
            result.append(cur.strip())
        return result
    
    def _strip_inline_comment(self, line: str) -> str:
        """去掉 ABAP 行内注释（双引号后的内容，字符串用单引号）。"""
        in_str = False
        out = []
        for ch in line:
            if ch == "'" and not in_str:
                in_str = True
                out.append(ch)
            elif ch == "'" and in_str:
                in_str = False
                out.append(ch)
            elif ch == '"' and not in_str:
                break
            else:
                out.append(ch)
        return ''.join(out)
    
    def _extract_function_refs(self, lines: List[str]) -> List[str]:
        """提取调用的函数模块"""
        functions = set()
        for line in lines:
            matches = FUNC_CALL_PATTERN.findall(line)
            for m in matches:
                functions.add(m.upper())
        return sorted(functions)
    
    def _extract_program_refs(self, lines: List[str]) -> List[str]:
        """提取调用的程序"""
        programs = set()
        for line in lines:
            matches = PROG_CALL_PATTERN.findall(line)
            for m in matches:
                programs.add(m.upper())
        return sorted(programs)
    
    def _analyze_overall_logic(self, lines: List[str], source_type: str,
                                table_refs: List[str], function_refs: List[str],
                                program_refs: List[str],
                                user_hints: List[str] = None,
                                uncertain_refs: List[str] = None) -> str:
        """分析程序的整体业务逻辑，生成抬头说明文本
        
        基于代码结构自动推断业务逻辑，包括核心问题、数据流程、
        输出形式和业务规则。用户提示信息会以标注来源的方式融入分析。
        table_refs 为确认的数据库表（已排除局部内表），uncertain_refs 为不确定对象。
        """
        parts = []
        

        # 1. 程序类型
        type_map = {
            'REPORT': '报表程序',
            'FUNCTION': '函数模块',
            'CLASS': '类定义',
            'MODULE_POOL': '模块池程序',
            'INCLUDE': '包含程序',
            'CDS': 'CDS视图定义',
            'AMDP': 'AMDP方法',
            'ABAP_GENERIC': 'ABAP通用程序',
            'SNIPPET': '代码片段',
            'MARKDOWN': 'Markdown中的代码',
        }
        type_desc = type_map.get(source_type, source_type)
        parts.append(f"程序类型: {type_desc}")
        
        # 2. 首次检测到的程序名/报表名
        for line in lines[:15]:
            name_match = re.search(r'(?:REPORT|PROGRAM)\s+(\S+)', line, re.IGNORECASE)
            if name_match:
                parts.append(f"程序名称: {name_match.group(1).rstrip('.')}")
                break
        
        # 3. 代码统计
        total = len(lines)
        code_lines = sum(1 for l in lines if l.strip() and not l.strip().startswith('*')
                        and not l.strip().startswith('"'))
        comment_lines = sum(1 for l in lines if l.strip().startswith('*')
                          or l.strip().startswith('"'))
        parts.append(f"代码规模: 共 {total} 行（有效代码 {code_lines} 行，注释 {comment_lines} 行）")
        
        # 4. 涉及的数据库表
        if table_refs:
            table_desc = []
            for t in table_refs:
                desc = SAP_TABLES.get(t.upper(), '')
                table_desc.append(f"{t}" + (f"（{desc}）" if desc else ""))
            parts.append(f"涉及数据表 ({len(table_refs)}): " + ", ".join(table_desc[:10]))
            if len(table_refs) > 10:
                parts.append(f"  ...及其他 {len(table_refs) - 10} 个表")
        
        # 4b. 不确定的表引用（无法确认是否为数据库表）
        if uncertain_refs:
            parts.append(f"不确定引用 ({len(uncertain_refs)}): " + ", ".join(uncertain_refs[:10]))
        
        # 5. 调用的函数模块
        if function_refs:
            parts.append(f"调用函数模块 ({len(function_refs)}): " + ", ".join(function_refs[:10]))
        
        # 6. 调用的程序
        if program_refs:
            parts.append(f"调用程序 ({len(program_refs)}): " + ", ".join(program_refs))
        
        # 7. 主要事件块/处理块
        events_found = []
        event_patterns = [
            ('START-OF-SELECTION', '选择开始事件'),
            ('END-OF-SELECTION', '选择结束事件'),
            ('INITIALIZATION', '初始化事件'),
            ('TOP-OF-PAGE', '页头事件'),
            ('AT SELECTION-SCREEN', '选择屏幕事件'),
            ('AT LINE-SELECTION', '行选择事件'),
            ('AT USER-COMMAND', '用户命令事件'),
            ('GET ', 'GET事件（逻辑数据库）'),
        ]
        for pattern, desc in event_patterns:
            if any(re.search(pattern, line, re.IGNORECASE) for line in lines):
                events_found.append(desc)
        if events_found:
            parts.append(f"包含事件块: " + ", ".join(events_found))
        
        # 8. 子程序/方法
        forms = [re.search(r'FORM\s+(\S+)', line, re.IGNORECASE) for line in lines]
        form_names = [m.group(1).rstrip('.') for m in forms if m]
        methods = [re.search(r'METHOD\s+(\S+)', line, re.IGNORECASE) for line in lines]
        method_names = [m.group(1).rstrip('.') for m in methods if m]
        
        if form_names:
            parts.append(f"包含子程序 ({len(form_names)}): " + ", ".join(form_names[:10]))
        if method_names:
            parts.append(f"包含方法 ({len(method_names)}): " + ", ".join(method_names[:10]))
        
        # 9. 业务逻辑深度分析（基于已收集的结构信息自动推断）
        parts.append("")
        parts.append("【整体逻辑】")
        
        # 分析核心业务问题
        biz_problem = self._infer_business_problem(lines, source_type, table_refs, function_refs, form_names, events_found)
        parts.append(f"  核心业务问题: {biz_problem}")
        
        # 分析数据来源和处理流程
        data_flow = self._infer_data_flow(lines, table_refs, function_refs, form_names)
        parts.append(f"  数据来源与处理流程: {data_flow}")
        
        # 分析输出结果形式
        output_form = self._infer_output_form(lines, events_found)
        parts.append(f"  输出结果形式: {output_form}")
        
        # 分析关键业务规则
        biz_rules = self._infer_business_rules(lines, table_refs, function_refs, form_names)
        parts.append(f"  关键业务规则与校验: {biz_rules}")
        
        return '\n'.join(parts)
    
    def _generate_line_annotations(self, lines: List[str],
                                    block_map: Dict[int, Dict],
                                    table_refs: List[str]) -> List[CodeAnnotation]:
        """生成逐行代码说明"""
        annotations = []
        
        for i, line in enumerate(lines):
            line_no = i + 1  # 1-based
            stripped = line.strip()
            
            # 跳过空行
            if not stripped:
                continue
            
            # 跳过纯ABAP注释行（原有注释保留，不加额外说明）
            if stripped.startswith('*') or stripped.startswith('"'):
                continue
            
            # 确定本行的代码块上下文
            block_type = ""
            block_context = ""
            is_block_start = False
            is_block_end = False
            
            if line_no in block_map:
                info = block_map[line_no]
                block_type = info['type']
                block_context = info['context']
                is_block_start = info['action'] == 'start'
                is_block_end = info['action'] == 'end'
            
            # 生成代码说明
            explanation = self._explain_line(stripped, line_no, table_refs)
            
            annotations.append(CodeAnnotation(
                line_number=line_no,
                original_code=line.rstrip(),
                explanation=explanation,
                block_type=block_type,
                block_context=block_context,
                is_block_start=is_block_start,
                is_block_end=is_block_end
            ))
        
        return annotations
    
    def _explain_line(self, line: str, line_no: int, table_refs: List[str]) -> str:
        """为单行代码生成业务说明"""
        upper = line.upper().strip().rstrip('.')
        explanation = ""
        
        # 1. 检查是否为代码块开始/结束行（这些行的说明由 block_context 提供）
        # 但仍为非块行生成说明
        
        # 2. SELECT 语句
        if re.search(r'\bSELECT\b', upper):
            explanation = self._explain_select(line)
        # 3. LOOP 语句
        elif re.search(r'\bLOOP\s+AT\b', upper):
            explanation = self._explain_loop(line)
        # 4. IF 条件
        elif re.search(r'\bIF\b', upper) and not re.search(r'\bIF\s+NOT\b', upper):
            explanation = self._explain_if(line)
        # 5. WRITE 输出
        elif re.search(r'\bWRITE\b', upper):
            explanation = self._explain_write(line)
        # 6. CALL FUNCTION
        elif re.search(r'\bCALL\s+FUNCTION\b', upper):
            explanation = self._explain_call_function(line)
        # 7. PERFORM
        elif re.search(r'\bPERFORM\b', upper):
            explanation = self._explain_perform(line)
        # 8. APPEND/COLLECT/INSERT INTO (内表)
        elif re.search(r'\bAPPEND\b', upper):
            explanation = self._explain_append(line)
        elif re.search(r'\bCOLLECT\b', upper):
            explanation = "将数据按唯一键汇总后追加到内表（相同键值的数值字段会自动累加）"
        elif re.search(r'\bINSERT\b', upper) and re.search(r'\bINTO\s+(TABLE|INDEX)\b', upper):
            explanation = self._explain_insert_table(line)
        # 9. READ TABLE
        elif re.search(r'\bREAD\s+TABLE\b', upper):
            explanation = self._explain_read_table(line)
        # 10. MODIFY (内表)
        elif re.search(r'\bMODIFY\b', upper) and not re.search(r'\bMODIFY\s+\S+\s+FROM\b', upper):
            explanation = self._explain_modify(line)
        # 11. DELETE (内表)
        elif re.search(r'\bDELETE\b', upper) and (re.search(r'\bFROM\b', upper) or re.search(r'\bINDEX\b', upper) or re.search(r'\bWHERE\b', upper)):
            explanation = self._explain_delete(line)
        # 12. SORT
        elif re.search(r'\bSORT\b', upper):
            explanation = self._explain_sort(line)
        # 13. CLEAR
        elif re.search(r'\bCLEAR\b', upper):
            var_match = re.search(r'CLEAR\s+(\S+)', upper)
            var = var_match.group(1) if var_match else "变量"
            explanation = f"清空 {var} 的内容"
        # 14. MOVE / 赋值
        elif re.search(r'\bMOVE\b', upper):
            explanation = self._explain_move(line)
        # 15. CONCATENATE
        elif re.search(r'\bCONCATENATE\b', upper):
            explanation = "将多个字符串拼接成一个字符串"
        # 16. SPLIT
        elif re.search(r'\bSPLIT\b', upper):
            explanation = "按指定分隔符拆分字符串到内表"
        # 17. MESSAGE
        elif re.search(r'\bMESSAGE\b', upper):
            explanation = self._explain_message(line)
        # 18. SUBMIT
        elif re.search(r'\bSUBMIT\b', upper):
            prog_match = re.search(r'SUBMIT\s+(\S+)', upper)
            prog = prog_match.group(1) if prog_match else "外部程序"
            explanation = f"调用外部报表程序 {prog}"
        # 19. LEAVE
        elif re.search(r'\bLEAVE\b', upper):
            if 'PROGRAM' in upper:
                explanation = "退出当前程序"
            elif 'TRANSACTION' in upper:
                explanation = "跳转到指定事务代码"
            elif 'SCREEN' in upper:
                explanation = "退出当前屏幕"
            elif 'LIST-PROCESSING' in upper:
                explanation = "退出列表处理"
            else:
                explanation = "退出当前处理块"
        # 20. DATA / TYPES 定义
        elif re.search(r'\bDATA\b', upper):
            explanation = self._explain_data(line)
        elif re.search(r'\bTYPES\b', upper):
            explanation = self._explain_types(line)
        elif re.search(r'\bFIELD-SYMBOLS\b', upper):
            fs_match = re.search(r'FIELD-SYMBOLS\s*:?\s*<(\S+)>', line)
            fs = fs_match.group(1) if fs_match else "<字段符号>"
            explanation = f"声明字段符号 <{fs}>（类似指针，用于动态引用内表行或数据对象）"
        # 21. PARAMETERS / SELECT-OPTIONS
        elif re.search(r'\bPARAMETERS\b', upper):
            explanation = self._explain_parameters(line)
        elif re.search(r'\bSELECT-OPTIONS\b', upper):
            explanation = self._explain_select_options(line)
        # 22. 事件块
        elif re.search(r'\bSTART-OF-SELECTION\b', upper):
            explanation = "* 核心处理开始事件：报表程序的主处理逻辑从此处开始执行"
        elif re.search(r'\bEND-OF-SELECTION\b', upper):
            explanation = "选择结束事件：主逻辑处理完毕后的收尾操作（如输出汇总）"
        elif re.search(r'\bINITIALIZATION\b', upper):
            explanation = "初始化事件：在选择屏幕显示前执行，用于设置默认值"
        elif re.search(r'\bTOP-OF-PAGE\b', upper):
            explanation = "页头事件：每输出新页时触发，用于打印报表表头"
        elif re.search(r'\bAT\s+SELECTION-SCREEN\b', upper):
            explanation = "选择屏幕事件：用户在屏幕上操作时触发（输入校验等）"
        elif re.search(r'\bAT\s+LINE-SELECTION\b', upper):
            explanation = "行选择事件：用户双击报表输出列表行时触发"
        elif re.search(r'\bAT\s+USER-COMMAND\b', upper):
            explanation = "用户命令事件：用户点击自定义按钮时触发"
        # 23. AUTHORITY-CHECK
        elif re.search(r'\bAUTHORITY-CHECK\b', upper):
            obj_match = re.search(r"OBJECT\s+'(\S+)'", line)
            obj = obj_match.group(1) if obj_match else "授权对象"
            explanation = f"权限检查：验证当前用户对授权对象 {obj} 的操作权限"
        # 24. DESCRIBE TABLE
        elif re.search(r'\bDESCRIBE\s+TABLE\b', upper):
            explanation = "获取内表的属性（行数等元信息）"
        # 25. CREATE OBJECT
        elif re.search(r'\bCREATE\s+OBJECT\b', upper):
            cls_match = re.search(r'CREATE\s+OBJECT\s+(\S+)', upper)
            cls = cls_match.group(1) if cls_match else "对象"
            explanation = f"创建类的实例对象 {cls}"
        # 26. SET HANDLER
        elif re.search(r'\bSET\s+HANDLER\b', upper):
            explanation = "注册事件处理方法"
        # 27. RAISE EVENT
        elif re.search(r'\bRAISE\s+EVENT\b', upper):
            explanation = "触发类事件"
        # 28. CATCH
        elif re.search(r'\bCATCH\b', upper):
            exc_match = re.search(r'CATCH\s+(\S+)', upper)
            exc = exc_match.group(1) if exc_match else "异常"
            explanation = f"捕获 {exc} 类型的异常，执行异常处理逻辑"
        # 29. CHECK
        elif re.search(r'\bCHECK\b', upper):
            cond = re.sub(r'^\s*CHECK\s+', '', line.strip(), flags=re.IGNORECASE).rstrip('.')
            explanation = f"条件检查: 如果 {cond} 不满足，则跳过当前循环迭代或处理块"
        
        # 30. 如果没有匹配到关键字，尝试分析数据表引用
        if not explanation:
            # 检查是否引用了SAP标准表
            for table in SAP_TABLES:
                if re.search(r'\b' + re.escape(table) + r'\b', upper):
                    explanation = f"引用SAP标准表: {table}（{SAP_TABLES[table]}）"
                    break
        
        # 31. 仍未匹配，生成通用说明
        if not explanation:
            # 检查是否包含赋值操作
            if '=' in line and not line.strip().startswith('*'):
                explanation = "赋值/计算操作"
            elif line.strip().startswith('.'):
                explanation = "语句结束符（ABAP语句以句点结尾）"
            else:
                explanation = ""
        
        return explanation
    
    # ----------- 行级说明辅助方法 -----------
    
    def _explain_select(self, line: str) -> str:
        """解释 SELECT 语句"""
        upper = line.upper()
        
        # DISTINCT
        parts = []
        if 'DISTINCT' in upper:
            parts.append("去重")
        
        # 字段
        single = 'SINGLE' in upper
        if single:
            parts.append("读取单条记录")
        
        # 表名
        table_match = re.search(r'FROM\s+(\S+)', upper)
        if table_match:
            table = table_match.group(1).rstrip('.')
            table_desc = SAP_TABLES.get(table, '')
            desc = f"（{table_desc}）" if table_desc else ""
            parts.append(f"从 {table} {desc}")
        
        # UP TO
        up_to = re.search(r'UP\s+TO\s+(\d+)\s+ROWS', upper)
        if up_to:
            parts.append(f"最多取 {up_to.group(1)} 行")
        
        # WHERE
        if 'WHERE' in upper:
            parts.append("带筛选条件")
        
        # INTO
        into_match = re.search(r'INTO\s+(TABLE\s+)?(\S+)', upper)
        if into_match:
            target = into_match.group(2).rstrip(',')
            is_table = into_match.group(1) is not None
            if is_table:
                parts.append(f"结果存入内表 {target}")
            else:
                parts.append(f"结果放入工作区 {target}")
        
        # ORDER BY
        if 'ORDER BY' in upper:
            parts.append("按指定字段排序")
        
        # GROUP BY
        if 'GROUP BY' in upper:
            parts.append("按指定字段分组")
        
        # JOIN
        if 'JOIN' in upper:
            join_type = ''
            if 'INNER JOIN' in upper:
                join_type = '内连接'
            elif 'LEFT' in upper and 'JOIN' in upper:
                join_type = '左外连接'
            elif 'RIGHT' in upper and 'JOIN' in upper:
                join_type = '右外连接'
            elif 'FULL' in upper and 'JOIN' in upper:
                join_type = '全外连接'
            if join_type:
                parts.insert(0, join_type)
        
        return "数据库查询: " + "，".join(parts)
    
    def _explain_loop(self, line: str) -> str:
        """解释 LOOP 语句"""
        upper = line.upper()
        table_match = re.search(r'LOOP\s+AT\s+(\S+)', upper)
        table_name = table_match.group(1) if table_match else "内表"
        
        into_match = re.search(r'INTO\s+(\S+)', upper)
        wa = into_match.group(1).rstrip(',') if into_match else ""
        
        assigning_match = re.search(r'ASSIGNING\s+<(\S+)>', upper)
        fs = assigning_match.group(1) if assigning_match else ""
        
        ref_match = re.search(r'REFERENCE\s+INTO\s+DATA\((\S+)\)', upper, re.IGNORECASE)
        ref = ref_match.group(1) if ref_match else ""
        
        where_match = re.search(r'WHERE\b(.*)', upper)
        
        parts = [f"循环遍历内表 {table_name}"]
        
        if wa:
            parts.append(f"每行数据放入工作区 {wa}")
        if fs:
            parts.append(f"通过字段符号 <{fs}> 引用每行")
        if ref:
            parts.append(f"通过引用 {ref} 指向每行")
        if where_match:
            parts.append("带筛选条件")
        
        return "，".join(parts)
    
    def _explain_if(self, line: str) -> str:
        """解释 IF 条件"""
        cond = re.sub(r'^\s*IF\s+', '', line.strip(), flags=re.IGNORECASE).rstrip('.')
        
        # 检测常见条件模式
        if 'IS NOT INITIAL' in cond.upper():
            return f"条件判断: 检查变量不为空（有值）"
        elif 'IS INITIAL' in cond.upper():
            return f"条件判断: 检查变量为空（无值）"
        elif 'IS ASSIGNED' in cond.upper():
            return f"条件判断: 检查字段符号是否已分配内存"
        elif 'IS BOUND' in cond.upper():
            return f"条件判断: 检查引用变量是否已绑定对象"
        elif 'NOT ' in cond.upper()[:10]:
            return f"条件判断（取反）: {cond}"
        else:
            return f"条件判断: {cond}"
    
    def _explain_write(self, line: str) -> str:
        """解释 WRITE 语句"""
        upper = line.upper()
        parts = ["输出"]
        
        if '/' in line:
            parts.append("换行")
        
        if 'NO-GAP' in upper:
            parts.append("紧接上一输出（无空格）")
        
        if 'UNDER' in upper:
            parts.append("对齐到指定列下方")
        
        if 'COLOR' in upper:
            parts.append("带颜色")
        
        # 提取输出的内容
        content = re.sub(r'WRITE\s*:?\s*', '', line.strip(), flags=re.IGNORECASE).rstrip('.')
        if content:
            parts.append(f": {content}")
        
        return "，".join(parts)
    
    def _explain_call_function(self, line: str) -> str:
        """解释 CALL FUNCTION"""
        func_match = re.search(r"CALL\s+FUNCTION\s+'(\S+)'", line)
        if func_match:
            func_name = func_match.group(1)
            return f"调用函数模块 {func_name}"
        return "调用函数模块"
    
    def _explain_perform(self, line: str) -> str:
        """解释 PERFORM"""
        form_match = re.search(r'PERFORM\s+(\S+)', line.upper())
        if form_match:
            form_name = form_match.group(1).rstrip('.')
            using = re.search(r'USING\s+(.*)', line.upper())
            changing = re.search(r'CHANGING\s+(.*)', line.upper())
            tables = re.search(r'TABLES\s+(.*)', line.upper())
            parts = [f"调用子程序 {form_name}"]
            if tables:
                parts.append("传递内表参数")
            if using:
                parts.append("传递输入参数")
            if changing:
                parts.append("传递可修改参数")
            return "，".join(parts)
        return "调用子程序"
    
    def _explain_append(self, line: str) -> str:
        """解释 APPEND"""
        upper = line.upper()
        into_match = re.search(r'APPEND\s+(\S+)\s+TO\s+(\S+)', upper)
        if into_match:
            wa = into_match.group(1)
            table = into_match.group(2).rstrip('.')
            return f"将工作区 {wa} 的数据追加到内表 {table} 的末尾"
        
        # APPEND <wa> TO <itab> 或 APPEND INITIAL LINE
        if 'INITIAL LINE' in upper:
            itab_match = re.search(r'TO\s+(\S+)', upper)
            itab = itab_match.group(1).rstrip('.') if itab_match else "内表"
            return f"向内表 {itab} 追加一行初始空行"
        
        return "追加数据行到内表"
    
    def _explain_insert_table(self, line: str) -> str:
        """解释 INSERT INTO TABLE"""
        upper = line.upper()
        into_match = re.search(r'INSERT\s+(\S+)\s+INTO\s+TABLE\s+(\S+)', upper)
        if into_match:
            wa = into_match.group(1)
            table = into_match.group(2).rstrip('.')
            return f"将工作区 {wa} 插入内表 {table}（使用内表索引）"
        
        index_match = re.search(r'INSERT\s+(\S+)\s+INTO\s+(\S+)\s+INDEX\s+(\d+)', upper)
        if index_match:
            wa = index_match.group(1)
            table = index_match.group(2)
            idx = index_match.group(3)
            return f"将工作区 {wa} 插入内表 {table} 的第 {idx} 行位置"
        
        return "向内表插入行"
    
    def _explain_read_table(self, line: str) -> str:
        """解释 READ TABLE"""
        upper = line.upper()
        table_match = re.search(r'READ\s+TABLE\s+(\S+)', upper)
        table = table_match.group(1) if table_match else "内表"
        
        parts = [f"从内表 {table} 中读取"]
        
        into_match = re.search(r'INTO\s+(\S+)', upper)
        assigning_match = re.search(r'ASSIGNING\s+<(\S+)>', upper)
        ref_match = re.search(r'REFERENCE\s+INTO\s+DATA\((\S+)\)', upper, re.IGNORECASE)
        
        if into_match:
            parts.append(f"结果放入工作区 {into_match.group(1).rstrip(',')}")
        if assigning_match:
            parts.append(f"通过字段符号 <{assigning_match.group(1)}> 引用")
        if ref_match:
            parts.append(f"通过引用 {ref_match.group(1)} 指向")
        
        if 'WITH KEY' in upper:
            key_part = re.search(r'WITH\s+KEY\s+(.*?)(?:\s+INTO|\s+BINARY|$)', upper)
            if key_part:
                parts.append(f"按指定键值查找: {key_part.group(1).strip().rstrip(',')}")
        elif 'INDEX' in upper:
            idx_match = re.search(r'INDEX\s+(\d+)', upper)
            if idx_match:
                parts.append(f"按索引第 {idx_match.group(1)} 行读取")
        
        if 'BINARY SEARCH' in upper:
            parts.append("（使用二分查找）")
        
        return "，".join(parts)
    
    def _explain_modify(self, line: str) -> str:
        """解释 MODIFY"""
        upper = line.upper()
        
        # MODIFY <itab> FROM <wa>
        from_match = re.search(r'MODIFY\s+(\S+)\s+FROM\s+(\S+)', upper)
        if from_match:
            return f"用工作区 {from_match.group(2).rstrip(',')} 的数据修改内表 {from_match.group(1)} 中对应的行"
        
        # MODIFY <itab> TRANSPORTING ...
        transport_match = re.search(r'MODIFY\s+(\S+)\s+TRANSPORTING\s+(.*?)(?:\s+WHERE|$)', upper)
        if transport_match:
            return f"修改内表 {transport_match.group(1)} 的指定字段: {transport_match.group(2).strip()}"
        
        # MODIFY <itab> WHERE ...
        where_match = re.search(r'MODIFY\s+(\S+)\s+WHERE\b', upper)
        if where_match:
            return f"按条件修改内表 {where_match.group(1)} 的行"
        
        return "修改内表行"
    
    def _explain_delete(self, line: str) -> str:
        """解释 DELETE"""
        upper = line.upper()
        
        # DELETE <itab> WHERE ...
        where_match = re.search(r'DELETE\s+(\S+)\s+WHERE\b', upper)
        if where_match:
            return f"按条件删除内表 {where_match.group(1)} 中的行"
        
        # DELETE <itab> INDEX ...
        idx_match = re.search(r'DELETE\s+(\S+)\s+INDEX\s+(\d+)', upper)
        if idx_match:
            return f"删除内表 {idx_match.group(1)} 中第 {idx_match.group(2)} 行"
        
        # DELETE ADJACENT DUPLICATES
        if 'ADJACENT DUPLICATES' in upper:
            table_match = re.search(r'FROM\s+(\S+)', upper)
            table = table_match.group(1) if table_match else "内表"
            return f"删除内表 {table} 中相邻的重复行"
        
        return "删除内表行"
    
    def _explain_sort(self, line: str) -> str:
        """解释 SORT"""
        upper = line.upper()
        table_match = re.search(r'SORT\s+(\S+)', upper)
        table = table_match.group(1) if table_match else "内表"
        
        if 'BY' in upper:
            by_part = re.search(r'BY\s+(.*)', upper)
            fields = by_part.group(1).strip().rstrip('.') if by_part else ""
            return f"对内表 {table} 按字段排序: {fields}"
        
        if 'AS TEXT' in upper:
            return f"对内表 {table} 按文本顺序排序"
        
        return f"对内表 {table} 进行排序"
    
    def _explain_message(self, line: str) -> str:
        """解释 MESSAGE"""
        id_match = re.search(r"MESSAGE\s+(\w\d{3})\((\S+)\)", line)
        if id_match:
            msg_id = id_match.group(1)
            msg_class = id_match.group(2).rstrip(')')
            type_match = re.search(r'MESSAGE\s+(\w)', line.upper())
            msg_type = type_match.group(1) if type_match else ""
            type_map = {'E': '错误', 'W': '警告', 'I': '信息', 'S': '成功', 'A': '终止'}
            type_desc = type_map.get(msg_type, msg_type)
            return f"输出{type_desc}消息: 消息类 {msg_class}，消息号 {msg_id}"
        
        with_match = re.search(r'MESSAGE\s+(\S+)', line.upper())
        if with_match:
            return f"输出消息: {with_match.group(1).rstrip('.')}"
        
        return "输出系统消息"
    
    def _explain_data(self, line: str) -> str:
        """解释 DATA 定义"""
        upper = line.upper().strip()
        
        # DATA: BEGIN OF ...
        if 'BEGIN OF' in upper:
            name_match = re.search(r'DATA\s*:?s*\s*BEGIN\s+OF\s+(\S+)', upper)
            name = name_match.group(1).rstrip(',') if name_match else "内表"
            if 'OCCURS' in upper:
                return f"定义内表 {name}（带表头行）"
            return f"定义结构体/内表 {name}"
        
        # DATA: lt_tab TYPE TABLE OF ...
        table_of_match = re.search(r'DATA\s+(\S+)\s+TYPE\s+(?:STANDARD|SORTED|HASHED)?\s*TABLE\s+OF', upper)
        if table_of_match:
            name = table_of_match.group(1).rstrip(',')
            return f"定义内表变量 {name}"
        
        # DATA: ls_wa TYPE / LIKE ...
        var_match = re.search(r'DATA\s+(\S+)\s+(?:TYPE|LIKE)', upper)
        if var_match:
            name = var_match.group(1).rstrip(':,')
            return f"定义变量 {name}"
        
        # DATA: <generic>
        generic_match = re.search(r'DATA\s+(\S+)', upper)
        if generic_match:
            name = generic_match.group(1).rstrip(':,')
            return f"定义数据对象 {name}"
        
        return "定义数据对象"
    
    def _explain_types(self, line: str) -> str:
        """解释 TYPES 定义"""
        upper = line.upper().strip()
        
        if 'BEGIN OF' in upper:
            name_match = re.search(r'TYPES\s*:?s*\s*BEGIN\s+OF\s+(\S+)', upper)
            name = name_match.group(1).rstrip(',') if name_match else "结构"
            return f"定义结构类型 {name}"
        
        type_match = re.search(r'TYPES\s+(\S+)', upper)
        if type_match:
            name = type_match.group(1).rstrip(':,')
            return f"定义数据类型 {name}"
        
        return "定义数据类型"
    
    def _explain_parameters(self, line: str) -> str:
        """解释 PARAMETERS"""
        match = re.search(r'PARAMETERS\s+(\S+)', line.upper())
        name = match.group(1).rstrip('.') if match else "参数"
        
        parts = [f"定义选择屏幕输入参数 {name}"]
        
        if 'OBLIGATORY' in line.upper():
            parts.append("（必填）")
        if 'DEFAULT' in line.upper():
            parts.append("（有默认值）")
        if 'AS CHECKBOX' in line.upper():
            parts.append("（复选框）")
        if 'RADIOBUTTON GROUP' in line.upper():
            parts.append("（单选按钮）")
        if 'NO-DISPLAY' in line.upper():
            parts.append("（隐藏）")
        
        return "，".join(parts)
    
    def _explain_select_options(self, line: str) -> str:
        """解释 SELECT-OPTIONS"""
        match = re.search(r'SELECT-OPTIONS\s+(\S+)\s+FOR\s+(\S+)', line.upper())
        if match:
            name = match.group(1).rstrip('.')
            field = match.group(2).rstrip('.')
            parts = [f"定义选择屏幕范围参数 {name}（关联字段 {field}）"]
            if 'OBLIGATORY' in line.upper():
                parts.append("（必填）")
            if 'NO INTERVALS' in line.upper():
                parts.append("（仅单值输入）")
            if 'NO-EXTENSION' in line.upper():
                parts.append("（不可多行）")
            return "，".join(parts)
        return "定义选择屏幕范围参数"
    
    def _explain_move(self, line: str) -> str:
        """解释 MOVE / 赋值"""
        upper = line.upper()
        # MOVE a TO b
        match = re.search(r'MOVE\s+(\S+)\s+TO\s+(\S+)', upper)
        if match:
            return f"将 {match.group(1).rstrip(',')} 的值赋给 {match.group(2).rstrip('.')}"
        return "赋值操作"
    
    def _compute_block_summary(self, block_map: Dict[int, Dict]) -> Dict:
        """计算代码块统计
        
        注意：BEGIN_OF 和 END_OF 成对出现，统一合并为 'BEGIN_OF...END_OF' 统计。
        其他块类型（LOOP/IF/FORM 等）的 start/end 在 _identify_blocks 中已
        通过 BLOCK_ENDS 映射回 start_type，天然是成对的。
        """
        summary = {}
        for line_no, info in block_map.items():
            btype = info['type']
            
            # BEGIN_OF / END_OF 合并统计
            display_type = 'BEGIN_OF...END_OF' if btype in ('BEGIN_OF', 'END_OF') else btype
            
            if display_type not in summary:
                summary[display_type] = {'count': 0, 'starts': [], 'ends': []}
            
            if info['action'] == 'start':
                summary[display_type]['count'] += 1
                summary[display_type]['starts'].append(line_no)
            else:
                summary[display_type]['ends'].append(line_no)
        
        # 对于 BEGIN_OF...END_OF，count 应为成对数量（取 starts 的数量）
        if 'BEGIN_OF...END_OF' in summary:
            summary['BEGIN_OF...END_OF']['count'] = len(
                summary['BEGIN_OF...END_OF']['starts']
            )
        
        return summary
    
    # ----------- 业务逻辑推断方法 -----------
    
    def _classify_table_domain(self, table: str) -> str:
        """根据表名推断业务领域"""
        t = table.upper()
        mm_tables = {'MARA', 'MAKT', 'MARD', 'MSEG', 'MKPF', 'STPO', 'STKO', 'RESB', 'PLAF', 'AFKO', 'AFPO', 'AUFK'}
        sd_tables = {'VBAK', 'VBAP', 'VBFA', 'LIPS', 'LIKP', 'VBRK', 'VBRP', 'KNA1', 'KNB1', 'KNVP'}
        fi_tables = {'BSEG', 'BKPF', 'BSIS', 'BSAS', 'BSIK', 'BSAK', 'BSID', 'BSAD', 'SKAT'}
        co_tables = {'CSKT', 'COBK', 'COEP'}
        mm_buy_tables = {'EKPO', 'EKKO', 'LFA1', 'LFB1', 'T024'}
        
        if t in mm_tables:
            return 'MM（物料管理/生产）'
        elif t in sd_tables:
            return 'SD（销售与分销）'
        elif t in fi_tables:
            return 'FI（财务会计）'
        elif t in co_tables:
            return 'CO（成本控制）'
        elif t in mm_buy_tables:
            return 'MM（采购管理）'
        else:
            return ''
    
    def _infer_business_problem(self, lines: List[str], source_type: str,
                                 table_refs: List[str], function_refs: List[str],
                                 form_names: List[str], events_found: List[str]) -> str:
        """推断程序解决的核心业务问题"""
        # 确定业务领域
        domains = set()
        for t in table_refs:
            d = self._classify_table_domain(t)
            if d:
                domains.add(d)
        domain_str = '、'.join(sorted(domains)) if domains else '通用'
        
        # 根据事件块和子程序推断程序用途
        has_report = 'TOP-OF-PAGE' in events_found or 'WRITE' in str(lines)
        has_auth = any('AUTHORITY-CHECK' in l.upper() for l in lines)
        has_enqueue = any('ENQUEUE' in f.upper() for f in function_refs)
        has_bdc = any('BDC' in l.upper() or 'CALL TRANSACTION' in l.upper() for l in lines)
        has_alv = any('REUSE_ALV' in l.upper() or 'CL_GUI_ALV' in l.upper() for l in lines)
        has_idoc = any('IDOC' in l.upper() for l in lines)
        has_batch = any('BATCH' in l.upper() or 'JOB_' in f.upper() for f in function_refs for l in lines)
        
        # 选择屏幕参数推断
        param_count = sum(1 for l in lines[:50] if re.search(r'\bPARAMETERS\b', l, re.IGNORECASE))
        selopt_count = sum(1 for l in lines[:50] if re.search(r'\bSELECT-OPTIONS\b', l, re.IGNORECASE))
        
        # 组装业务描述
        parts = []
        
        # 判断程序类型特征
        if has_bdc:
            parts.append("通过批输入/调用事务进行数据批量处理")
        elif has_alv:
            parts.append("以ALV网格报表形式展示数据")
        elif has_idoc:
            parts.append("处理IDoc接口数据的发送或接收")
        elif has_batch:
            parts.append("后台批量作业处理")
        elif has_report and has_auth:
            parts.append("带权限控制的查询报表")
        elif has_report:
            parts.append("数据查询与报表输出")
        elif has_enqueue:
            parts.append("带数据锁定的业务处理")
        else:
            parts.append("业务数据处理程序")
        
        parts.append(f"（涉及{domain_str}领域")
        
        if table_refs:
            top_tables = [t for t in table_refs[:5] if t in SAP_TABLES]
            if top_tables:
                table_desc = '、'.join([f"{t}（{SAP_TABLES[t]}）" for t in top_tables])
                parts.append(f"，核心表: {table_desc}")
        
        parts.append("）")
        
        return ''.join(parts)
    
    def _infer_data_flow(self, lines: List[str], table_refs: List[str],
                          function_refs: List[str], form_names: List[str]) -> str:
        """推断数据来源和处理流程
        
        注意：使用已确认的 table_refs（排除了局部内表）作为数据表来源，
        而非再次用正则扫描 FROM。
        """
        # 使用已确认的数据库表来描述数据来源
        select_tables = []
        for t in table_refs:
            if t in SAP_TABLES:
                select_tables.append(f"{t}（{SAP_TABLES[t]}）")
            else:
                select_tables.append(t)
        
        # 检测JOIN连接
        joins = []
        for line in lines:
            if re.search(r'\bJOIN\b', line, re.IGNORECASE):
                if 'INNER JOIN' in line.upper():
                    joins.append('内连接')
                elif 'LEFT' in line.upper() and 'JOIN' in line.upper():
                    joins.append('左外连接')
                elif 'RIGHT' in line.upper() and 'JOIN' in line.upper():
                    joins.append('右外连接')
        
        # 检测数据写入操作
        write_ops = []
        if any(re.search(r'\bMODIFY\s+\w+\s+FROM\b', l, re.IGNORECASE) for l in lines):
            write_ops.append("MODIFY更新数据库表")
        if any(re.search(r'\bINSERT\s+\w+\s+FROM\b', l, re.IGNORECASE) for l in lines):
            write_ops.append("INSERT插入数据库表")
        if any(re.search(r'\bUPDATE\s+\w+\s+SET\b', l, re.IGNORECASE) for l in lines):
            write_ops.append("UPDATE更新数据库")
        if any(re.search(r'\bDELETE\s+FROM\b', l, re.IGNORECASE) for l in lines) or \
           any(re.search(r'\bDELETE\s+\w+\s+FROM\b', l, re.IGNORECASE) for l in lines):
            write_ops.append("DELETE删除数据")
        
        # 检测内表处理
        has_loop = any(re.search(r'\bLOOP\s+AT\b', l, re.IGNORECASE) for l in lines)
        has_sort = any(re.search(r'\bSORT\b', l, re.IGNORECASE) for l in lines)
        has_collect = any(re.search(r'\bCOLLECT\b', l, re.IGNORECASE) for l in lines)
        has_read_table = any(re.search(r'\bREAD\s+TABLE\b', l, re.IGNORECASE) for l in lines)
        
        # 组装数据流程描述
        flow_parts = []
        
        if select_tables:
            unique_tables = list(dict.fromkeys(select_tables))[:8]  # 去重且限制数量
            flow_parts.append(f"数据从 {len(unique_tables)} 个数据库表读取: {'、'.join(unique_tables)}")
        
        if joins:
            flow_parts.append(f"通过{'、'.join(set(joins))}关联查询")
        
        flow_parts.append("数据在内存内表中加工处理")
        if has_loop:
            flow_parts.append("（遍历、筛选、计算）")
        if has_sort:
            flow_parts.append("（排序）")
        if has_collect:
            flow_parts.append("（汇总）")
        
        if function_refs:
            func_descs = []
            for f in function_refs[:5]:
                fu = f.upper()
                if 'CONVERSION' in fu or 'CONVERT' in fu:
                    func_descs.append(f"{f}（格式转换）")
                elif 'DATE' in fu or 'TIME' in fu:
                    func_descs.append(f"{f}（日期/时间处理）")
                elif 'ENQUEUE' in fu or 'DEQUEUE' in fu:
                    func_descs.append(f"{f}（数据锁定）")
                elif 'READ' in fu or 'GET' in fu:
                    func_descs.append(f"{f}（数据读取）")
                elif 'WRITE' in fu or 'UPDATE' in fu or 'MODIFY' in fu:
                    func_descs.append(f"{f}（数据写入）")
                else:
                    func_descs.append(f)
            flow_parts.append(f"，调用 {len(function_refs)} 个函数模块辅助处理: {'、'.join(func_descs)}")
        
        if write_ops:
            flow_parts.append(f"；对数据库执行写操作: {'、'.join(write_ops)}")
        
        return ''.join(flow_parts)
    
    def _infer_output_form(self, lines: List[str], events_found: List[str]) -> str:
        """推断输出结果形式"""
        # 检测输出类型
        has_alv = any('REUSE_ALV' in l.upper() for l in lines)
        has_alv_grid = any('CL_GUI_ALV_GRID' in l.upper() for l in lines)
        has_write = any(re.search(r'\bWRITE\b', l, re.IGNORECASE) for l in lines)
        has_top_page = 'TOP-OF-PAGE' in events_found
        has_new_page = any(re.search(r'\bNEW-PAGE\b', l, re.IGNORECASE) for l in lines)
        has_new_line = any(re.search(r'\bNEW-LINE\b', l, re.IGNORECASE) for l in lines)
        has_uline = any(re.search(r'\bULINE\b', l, re.IGNORECASE) for l in lines)
        has_format = any(re.search(r'\bFORMAT\b', l, re.IGNORECASE) for l in lines)
        has_color = any('COLOR' in l.upper() and 'WRITE' in l.upper() for l in lines)
        has_hide = any(re.search(r'\bHIDE\b', l, re.IGNORECASE) for l in lines)
        has_export = any(re.search(r'\bEXPORT\b', l, re.IGNORECASE) for l in lines)
        has_download = any('DOWNLOAD' in l.upper() or 'GUI_DOWNLOAD' in l.upper() for l in lines)
        has_spool = any('SPOOL' in l.upper() or 'NEW-PAGE PRINT' in l.upper() for l in lines)
        has_bdc = any('BDC' in l.upper() or 'CALL TRANSACTION' in l.upper() for l in lines)
        has_message = any(re.search(r'\bMESSAGE\b', l, re.IGNORECASE) for l in lines)
        
        # 判断输出形式
        if has_alv_grid:
            return "ALV网格报表（可交互的列表展示，支持排序、过滤、导出）"
        elif has_alv:
            return "ALV列表报表（标准SAP报表展示方式）"
        elif has_bdc:
            return "通过BDC/Call Transaction执行事务操作（无列表输出）"
        elif has_download:
            return "下载为本地文件（Excel/文本格式）"
        elif has_export:
            return "导出数据到内存/数据库"
        elif has_write and (has_top_page or has_new_page):
            return "格式化列表报表输出（带页头、分页、下划线等排版）"
        elif has_write:
            return "列表输出（WRITE语句直接输出到屏幕）"
        elif has_message and not has_write:
            return "消息提示（无列表输出，仅输出状态/结果消息）"
        elif has_spool:
            return "后台打印输出（通过SPOOL产生打印报表）"
        else:
            return "数据处理/后台执行（无直接屏幕输出）"
    
    def _infer_business_rules(self, lines: List[str], table_refs: List[str],
                               function_refs: List[str], form_names: List[str]) -> str:
        """推断关键业务规则和校验逻辑"""
        rules = []
        
        # 权限检查
        auth_objects = set()
        for line in lines:
            m = re.search(r"AUTHORITY-CHECK\s+OBJECT\s+'(\S+)'", line, re.IGNORECASE)
            if m:
                auth_objects.add(m.group(1))
        if auth_objects:
            rules.append(f"权限控制: 检查授权对象 {'、'.join(auth_objects)}")
        
        # 数据锁定
        enqueue_funcs = [f for f in function_refs if 'ENQUEUE' in f.upper()]
        dequeue_funcs = [f for f in function_refs if 'DEQUEUE' in f.upper()]
        if enqueue_funcs:
            rules.append(f"数据锁定: 调用 {', '.join(enqueue_funcs)} 防止并发修改")
        
        # BADI/UserExit
        has_badi = any('BADI' in l.upper() or 'CL_EXITHANDLER' in l.upper() for l in lines)
        has_exit = any('USER_EXIT' in l.upper() or 'EXIT_' in l.upper() or 'CALL CUSTOMER' in l.upper() for l in lines)
        if has_badi:
            rules.append("扩展点: 使用BADI增强（可由实施团队自定义逻辑）")
        if has_exit:
            rules.append("扩展点: 调用User Exit/用户出口")
        
        # 输入校验
        has_at_selection = any('AT SELECTION-SCREEN' in l.upper() for l in lines)
        has_required = any('OBLIGATORY' in l.upper() for l in lines)
        has_message_type = set()
        for line in lines:
            m = re.search(r'\bMESSAGE\s+(\w)', line, re.IGNORECASE)
            if m:
                has_message_type.add(m.group(1).upper())
        if has_at_selection:
            rules.append("输入校验: 在选择屏幕事件中校验用户输入")
        if has_required:
            rules.append("必填约束: 部分选择屏幕参数设为必填")
        if 'E' in has_message_type:
            rules.append("错误处理: 包含错误消息（TYPE E），遇到错误时终止处理")
        if 'W' in has_message_type:
            rules.append("警告处理: 包含警告消息（TYPE W），提醒用户注意")
        
        # 数据完整性
        has_commit = any(re.search(r'\bCOMMIT\s+WORK\b', l, re.IGNORECASE) for l in lines)
        has_rollback = any(re.search(r'\bROLLBACK\s+WORK\b', l, re.IGNORECASE) for l in lines)
        has_check = any(re.search(r'\bCHECK\b', l, re.IGNORECASE) for l in lines)
        if has_commit:
            rules.append("事务完整性: 使用COMMIT WORK提交数据库更改")
        if has_rollback:
            rules.append("事务完整性: 使用ROLLBACK WORK回滚数据库更改")
        if has_check:
            rules.append("条件守卫: 使用CHECK语句在循环/事件中控制执行流程")
        
        # 异常处理
        has_try = any(re.search(r'\bTRY\b', l, re.IGNORECASE) for l in lines)
        if has_try:
            rules.append("异常处理: 使用TRY/CATCH结构捕获运行时异常")
        
        # 特殊逻辑
        has_delete_adju = any('DELETE ADJACENT DUPLICATES' in l.upper() for l in lines)
        if has_delete_adju:
            rules.append("数据去重: 删除内表中相邻的重复记录")
        
        if not rules:
            rules.append("基于代码结构分析，本程序以数据查询和展示为主，未检测到复杂的业务规则校验")
        
        return '；'.join(rules)
    
    def _analyze_business_deep(self, lines: List[str], source_type: str,
                                table_refs: List[str], function_refs: List[str],
                                program_refs: List[str], form_names: List[str],
                                events_found: List[str],
                                user_hints: List[str] = None) -> BusinessAnalysisResult:
        """业务逻辑深度分析 — 基于代码结构自动推断程序的业务功能、模块划分和数据流向
        
        即使没有用户提示（hints），也能通过分析 FORM/子程序名、CASE 分支、
        数据库表、函数模块调用等推断出程序的业务定位和功能模块。
        """
        hints = user_hints or []

        # 1. 确定业务领域 — 如果用户提供了提示，直接从提示推断领域
        domains = set()
        if hints:
            hint_text = ' '.join(hints)
            if any(kw in hint_text for kw in ['财务', '开票', '发票', '费用', '费用池', 'FI', '会计']):
                domains.add('FI（财务会计）')
            if any(kw in hint_text for kw in ['销售', 'SD', '订单', '交货', '开票方', '客户']):
                domains.add('SD（销售与分销）')
            if any(kw in hint_text for kw in ['采购', 'MM', '物料', '供应商']):
                domains.add('MM（物料管理）')
            if any(kw in hint_text for kw in ['成本', 'CO', '利润中心']):
                domains.add('CO（成本控制）')

        # 补充从数据库表推断的领域
        for t in table_refs:
            d = self._classify_table_domain(t)
            if d:
                domains.add(d)

        # 对于含自定义Z表（如ZZFIT007等财务表）的情况，辅助判断FI领域
        has_zfi_table = any(re.match(r'ZZFI', t, re.IGNORECASE) for t in table_refs)
        if has_zfi_table and 'FI（财务会计）' not in domains:
            domains.add('FI（财务会计）')

        domain_str = '、'.join(sorted(domains)) if domains else '通用业务'
        
        # 2. 分析 CASE/WHEN 结构 → 功能模块入口
        case_modules = self._extract_case_modules(lines)
        
        # 3. 分析子程序名 → 推断功能
        form_analysis = self._analyze_form_names(form_names, lines)
        
        # 4. 分析主要数据表和函数
        table_desc_parts = self._build_table_description(table_refs)
        func_desc_parts = self._build_function_description(function_refs)
        
        # 5. 分析程序交互特征
        interaction_features = self._analyze_interaction_features(lines, function_refs)
        
        # 6. 组装程序定位
        program_position = self._build_program_position(
            source_type, domain_str, case_modules, form_names, lines, hints
        )
        
        # 7. 组装功能模块列表
        functional_modules = self._build_functional_modules(
            case_modules, form_analysis, lines, hints
        )
        
        # 8. 关键业务表说明
        key_tables_desc = table_desc_parts
        if func_desc_parts:
            key_tables_desc += "\n" + func_desc_parts
        
        # 9. 技术特征
        tech_features = self._build_technical_features(
            lines, function_refs, events_found, interaction_features
        )
        
        return BusinessAnalysisResult(
            program_position=program_position,
            business_domain=domain_str,
            functional_modules=functional_modules,
            key_tables_desc=key_tables_desc,
            technical_features=tech_features
        )
    
    def _extract_case_modules(self, lines: List[str]) -> List[Dict]:
        """从 CASE/WHEN 结构中提取功能模块

        只提取 START-OF-SELECTION（主处理流程）中的 CASE 块，
        过滤掉 AT SELECTION-SCREEN 中的动态屏幕逻辑 CASE 块。

        返回: [{name: WHEN值, context: 周围代码上下文, line: 行号,
                comment: 行尾注释, case_var: CASE变量名}]
        """
        modules = []
        case_depth = 0
        current_case_var = ""

        # 确定主处理区域的起始行（START-OF-SELECTION 之后）
        main_start = 0
        for i, line in enumerate(lines):
            if re.search(r'^\s*START-OF-SELECTION\s*\.', line, re.IGNORECASE):
                main_start = i + 1
                break

        # 确定事件块区域边界
        at_selection_start = len(lines)
        at_selection_end = len(lines)
        in_at_selection = False
        for i, line in enumerate(lines):
            stripped = line.strip().upper()
            if re.search(r'^\s*AT\s+SELECTION-SCREEN\b', line, re.IGNORECASE):
                if not in_at_selection:
                    at_selection_start = i
                    in_at_selection = True
            elif in_at_selection and re.search(
                r'^\s*(START-OF-SELECTION|END-OF-SELECTION|FORM\s|MODULE\s)', line, re.IGNORECASE):
                at_selection_end = i
                in_at_selection = False
                break

        for i, line in enumerate(lines):
            stripped = line.strip().upper()

            # 检测 CASE 语句
            case_match = re.search(r'^\s*CASE\s+(\S+)', line, re.IGNORECASE)
            if case_match:
                current_case_var = case_match.group(1).rstrip('.')
                case_depth += 1
                continue

            # 检测 WHEN（CASE 内部）
            if case_depth > 0:
                when_match = re.search(r'^\s*WHEN\s+(.+)', line, re.IGNORECASE)
                if when_match:
                    when_value = when_match.group(1).strip().rstrip('.')

                    # 过滤掉 AT SELECTION-SCREEN 中的动态屏幕逻辑 CASE
                    if at_selection_start <= i <= at_selection_end:
                        continue

                    # 提取 WHEN 行尾的注释
                    comment = ""
                    line_comment = re.search(r'\"(.+?)$', line)
                    if line_comment:
                        comment = line_comment.group(1).strip()

                    # 清理 WHEN 值：去掉行尾注释和引号
                    cleaned_when = re.sub(r'\".*$', '', when_value).strip()
                    # 去掉前缀引号
                    cleaned_when = re.sub(r'^["\']+', '', cleaned_when).strip()

                    # 获取 WHEN 块的后续几行代码作为上下文
                    context_lines = []
                    context_comments = []
                    for j in range(i + 1, min(i + 10, len(lines))):
                        next_stripped = lines[j].strip().upper()
                        if next_stripped.startswith('WHEN ') or next_stripped == 'ENDCASE.':
                            break
                        if lines[j].strip():
                            context_lines.append(lines[j].strip())
                            # 提取上下文行中的行尾注释
                            ctx_comment = re.search(r'\"(.+?)$', lines[j])
                            if ctx_comment:
                                context_comments.append(ctx_comment.group(1).strip())

                    # 提取 PERFORM 调用
                    perform_names = re.findall(r'PERFORM\s+(\S+)', '\n'.join(context_lines), re.IGNORECASE)
                    perform_names = [n.rstrip('.') for n in perform_names]

                    modules.append({
                        'name': cleaned_when,
                        'original_name': when_value,
                        'case_var': current_case_var,
                        'context': '\n'.join(context_lines),
                        'line': i + 1,
                        'comment': comment,
                        'context_comments': context_comments,
                        'perform_names': perform_names,
                    })

                if stripped == 'ENDCASE.':
                    case_depth -= 1

        return modules
    
    def _analyze_form_names(self, form_names: List[str], lines: List[str]) -> List[Dict]:
        """分析子程序名，推断每个子程序的业务功能
        
        返回: [{name: 子程序名, purpose: 推断的业务目的}]
        """
        results = []
        
        # 子程序名前缀/后缀 → 业务含义映射
        form_patterns = [
            (r'^(CREATE|CRE|ADD|NEW)', '创建/新增数据'),
            (r'^(DELETE|DEL|REMOVE|CANCEL|CAN)', '删除/取消'),
            (r'^(UPDATE|MOD|MODIFY|CHG|CHANGE)', '修改/更新'),
            (r'^(GET|READ|FETCH|SEL|SELECT|FIND|QUERY|SEARCH)', '查询/读取'),
            (r'^(DISPLAY|SHOW|VIEW|LIST|PRINT|OUTPUT)', '展示/输出'),
            (r'^(CHECK|VALIDATE|VERIFY)', '校验/验证'),
            (r'^(PROCESS|PROC|RUN|EXEC)', '处理/执行'),
            (r'^(CALC|COMPUTE|SUM|TOTAL)', '计算'),
            (r'^(CONVERT|TRANSFORM|MAP)', '转换/映射'),
            (r'^(EXPORT|DOWNLOAD|WRITE_FILE|OUTPUT)', '导出/下载'),
            (r'^(IMPORT|UPLOAD|READ_FILE|LOAD)', '导入/上传'),
            (r'^(LOCK|UNLOCK|ENQUEUE|DEQUEUE)', '锁定/解锁'),
            (r'^(INIT|INITIALIZE|SETUP|PREPARE)', '初始化/准备'),
            (r'^(CLEAR|RESET|CLEAN)', '清空/重置'),
            (r'^(SEND|POST|SUBMIT|CALL)', '发送/提交'),
            (r'^(REVERSE|CANCEL|ROLLBACK|UNDO)', '冲销/回滚'),
            (r'^(APPROVE|AUTH|AUTHORIZE)', '审批/授权'),
            (r'^(ALLOCATE|ASSIGN|DISTRIBUTE)', '分配'),
            (r'(DATA|INFO|DETAIL|ITEM|HEADER|LINE|ITEMS)$', '数据处理'),
            (r'(ALV|GRID|LIST|TABLE)$', '列表展示'),
            (r'(SCREEN|GUI|STATUS|PF|TOOLBAR)$', '界面处理'),
            (r'(POPUP|DIALOG|CONFIRM)$', '对话框/确认'),
        ]
        
        for fname in form_names:
            purpose = ""
            for pattern, meaning in form_patterns:
                if re.search(pattern, fname, re.IGNORECASE):
                    purpose = meaning
                    break
            
            # 尝试从子程序名中的下划线分隔词推断
            if not purpose:
                words = re.sub(r'([A-Z])', r' \1', fname).split()
                # 去掉常见的 ABAP 前缀
                words = [w for w in words if w.upper() not in ('FORM', 'F', 'ZF', 'Z', 'Y')]
                if words:
                    purpose = f"处理{'/'.join(words[:3])}"
            
            results.append({
                'name': fname,
                'purpose': purpose if purpose else '通用处理'
            })
        
        return results
    
    def _build_table_description(self, table_refs: List[str]) -> str:
        """构建关键业务表说明"""
        if not table_refs:
            return ""
        
        # 分为标准表和自定义表（Z/Y 开头）
        standard_tables = []
        custom_tables = []
        for t in table_refs:
            if t.startswith('Z') or t.startswith('Y'):
                custom_tables.append(t)
            elif t in SAP_TABLES:
                standard_tables.append(f"{t}（{SAP_TABLES[t]}）")
            else:
                standard_tables.append(t)
        
        parts = []
        if standard_tables:
            parts.append(f"SAP标准表: {'、'.join(standard_tables[:12])}")
        if custom_tables:
            parts.append(f"自定义表: {'、'.join(custom_tables[:10])}")
        
        return '\n'.join(parts)
    
    def _build_function_description(self, function_refs: List[str]) -> str:
        """构建关键函数模块说明"""
        if not function_refs:
            return ""
        
        # 分类函数
        func_categories = {
            '锁定/解锁': [],
            '格式转换': [],
            '日期时间': [],
            '消息输出': [],
            '数据读写': [],
            '用户信息': [],
            '其他': []
        }
        
        for f in function_refs:
            fu = f.upper()
            if 'ENQUEUE' in fu or 'DEQUEUE' in fu:
                func_categories['锁定/解锁'].append(f)
            elif 'CONVERSION' in fu or 'CONVERT' in fu:
                func_categories['格式转换'].append(f)
            elif 'DATE' in fu or 'TIME' in fu or 'CALCULATE' in fu:
                func_categories['日期时间'].append(f)
            elif 'MESSAGE' in fu or 'POPUP' in fu:
                func_categories['消息输出'].append(f)
            elif any(k in fu for k in ('READ', 'GET', 'WRITE', 'UPDATE', 'MODIFY')):
                func_categories['数据读写'].append(f)
            elif 'USER' in fu or 'CURRENT' in fu:
                func_categories['用户信息'].append(f)
            else:
                func_categories['其他'].append(f)
        
        parts = []
        for cat, funcs in func_categories.items():
            if funcs:
                parts.append(f"{cat}: {'、'.join(funcs[:5])}")
        
        return "关键函数模块: " + '；'.join(parts) if parts else ""
    
    def _analyze_interaction_features(self, lines: List[str], function_refs: List[str]) -> Dict:
        """分析程序的交互特征"""
        features = {}
        
        # 屏幕相关
        screen_defs = re.findall(r'SELECTION-SCREEN\s+BEGIN\s+OF\s+.*?BLOCK\s+(\S+)', 
                                  '\n'.join(lines), re.IGNORECASE)
        if screen_defs:
            features['selection_blocks'] = screen_defs
        
        # ALV
        has_alv = any('REUSE_ALV' in l.upper() or 'CL_GUI_ALV' in l.upper() for l in lines)
        features['has_alv'] = has_alv
        
        # BDC
        has_bdc = any('BDC' in l.upper() or 'CALL TRANSACTION' in l.upper() for l in lines)
        features['has_bdc'] = has_bdc
        
        # 权限
        auth_objects = set()
        for line in lines:
            m = re.search(r"AUTHORITY-CHECK\s+OBJECT\s+'(\S+)'", line, re.IGNORECASE)
            if m:
                auth_objects.add(m.group(1))
        if auth_objects:
            features['auth_objects'] = list(auth_objects)
        
        # 锁
        enqueue_funcs = [f for f in function_refs if 'ENQUEUE' in f.upper()]
        if enqueue_funcs:
            features['enqueue_funcs'] = enqueue_funcs
        
        return features
    
    def _build_program_position(self, source_type: str, domain_str: str,
                                 case_modules: List[Dict], form_names: List[str],
                                 lines: List[str], hints: List[str]) -> str:
        """组装程序定位描述 — 优先使用用户提示，用业务语言描述"""
        # 如果用户提供了提示，直接使用
        hint_context = ""
        if hints:
            hint_context = ''.join(hints)

        # 检测程序名
        prog_name = ""
        for line in lines[:15]:
            m = re.search(r'(?:REPORT|PROGRAM)\s+(\S+)', line, re.IGNORECASE)
            if m:
                prog_name = m.group(1).rstrip('.')
                break

        # 尝试从 PARAMETERS 注释中提取业务模块描述
        param_descriptions = []
        for line in lines[:80]:
            # 匹配 PARAMETERS: xxx RADIOBUTTON GROUP ... "业务描述
            param_match = re.search(
                r'PARAMETERS:\s*(\S+)\s+RADIOBUTTON\s+GROUP\s+\S+.*?\"(.+?)$', line)
            if param_match:
                param_descriptions.append(param_match.group(2).strip())

        # 判断程序类型
        type_map = {
            'REPORT': '报表程序', 'FUNCTION': '函数模块', 'CLASS': '类定义',
            'MODULE_POOL': '模块池程序', 'INCLUDE': '包含程序',
        }
        type_desc = type_map.get(source_type, 'ABAP程序')

        # 构建定位描述
        if hints:
            # 用户有提示时，以用户描述为主，辅以代码分析
            # 从提示中提取核心业务名称
            hint_text = ''.join(hints)
            # 去掉常见的前缀如"这个程序是"、"模块："等
            clean_hint = re.sub(r'^(这个程序是|该程序是|程序属于|：|:)\s*', '', hint_text)
            module_summary = ''
            if param_descriptions:
                # 过滤掉修改记录
                clean_params = []
                for pd in param_descriptions[:6]:
                    pd = re.sub(r'["\']*add---.*$', '', pd).strip()
                    pd = re.sub(r'["\']*modified\s*in.*$', '', pd, flags=re.IGNORECASE).strip()
                    if pd and len(pd) > 1 and pd not in clean_params:
                        clean_params.append(pd)
                if clean_params:
                    module_summary = '，提供' + '、'.join(clean_params) + '等功能'
            position = f"{prog_name} 是一个{type_desc}，业务定位为「{clean_hint}」{module_summary}"
        elif param_descriptions:
            # 没有用户提示但能从参数注释提取业务描述
            clean_params = []
            for pd in param_descriptions[:6]:
                pd = re.sub(r'["\']*add---.*$', '', pd).strip()
                pd = re.sub(r'["\']*modified\s*in.*$', '', pd, flags=re.IGNORECASE).strip()
                if pd and len(pd) > 1 and pd not in clean_params:
                    clean_params.append(pd)
            if clean_params:
                position = f"{prog_name} 是一个{domain_str}领域的{type_desc}，主要功能包括：{'、'.join(clean_params)}"
            else:
                position = f"{prog_name} 是一个{domain_str}领域的{type_desc}"
        elif len(case_modules) >= 3:
            position = f"{prog_name} 是一个 {domain_str} 领域的{type_desc}，包含 {len(case_modules)} 个功能入口（通过 CASE 语句路由）"
        elif len(form_names) >= 5:
            position = f"{prog_name} 是一个 {domain_str} 领域的{type_desc}，包含 {len(form_names)} 个子程序"
        else:
            position = f"{prog_name} 是一个 {domain_str} 领域的{type_desc}"

        return position
    
    def _build_functional_modules(self, case_modules: List[Dict],
                                   form_analysis: List[Dict],
                                   lines: List[str], hints: List[str]) -> List[str]:
        """组装功能模块列表 — 用业务语言而非技术术语描述每个模块

        策略：
        1. 优先使用 CASE 块的行尾注释（ABAP中 "xxx 是标准注释语法）
        2. 其次使用上下文中 PERFORM 调用行尾的注释
        3. 最后才基于关键词模式匹配推断
        """
        modules = []

        # 建立 PARAMETERS → 注释映射（选择屏幕参数的行尾注释是最佳业务线索）
        param_comment_map = {}
        for line in lines[:80]:
            # 匹配 PARAMETERS: xxx RADIOBUTTON GROUP ... "业务描述（带冒号）
            param_match = re.search(
                r'PARAMETERS:\s*(\S+)\s+.*?\"(.+?)$', line)
            if param_match:
                param_name = param_match.group(1).strip().upper()
                param_desc = param_match.group(2).strip()
                param_desc = re.sub(r'["\']*add---.*$', '', param_desc).strip()
                param_desc = re.sub(r'["\']*modified\s*in.*$', '', param_desc, flags=re.IGNORECASE).strip()
                param_desc = re.sub(r'^["\']+', '', param_desc)
                if param_desc and len(param_desc) > 1:
                    param_comment_map[param_name] = param_desc
                continue

            # ABAP 链式语法续行（以空白开头 + 参数名 + RADIOBUTTON）
            chain_match = re.search(
                r'^\s{2,}(\S+)\s+RADIOBUTTON\s+GROUP\s+\S+.*?\"(.+?)$', line)
            if chain_match:
                param_name = chain_match.group(1).strip().upper()
                param_desc = chain_match.group(2).strip()
                param_desc = re.sub(r'["\']*add---.*$', '', param_desc).strip()
                param_desc = re.sub(r'["\']*modified\s*in.*$', '', param_desc, flags=re.IGNORECASE).strip()
                param_desc = re.sub(r'^["\']+', '', param_desc)
                if param_desc and len(param_desc) > 1:
                    param_comment_map[param_name] = param_desc
                continue

            # 独立的 PARAMETERS（不带冒号）：PARAMETERS  r_query  RADIOBUTTON GROUP grp .  "查询暂存发票
            standalone_match = re.search(
                r'PARAMETERS\s+(\S+)\s+RADIOBUTTON\s+GROUP\s+\S+.*?\"(.+?)$', line)
            if standalone_match:
                param_name = standalone_match.group(1).strip().upper()
                param_desc = standalone_match.group(2).strip()
                param_desc = re.sub(r'["\']*add---.*$', '', param_desc).strip()
                param_desc = re.sub(r'["\']*modified\s*in.*$', '', param_desc, flags=re.IGNORECASE).strip()
                param_desc = re.sub(r'^["\']+', '', param_desc)
                if param_desc and len(param_desc) > 1:
                    param_comment_map[param_name] = param_desc

        # 建立 PERFORM → 行尾注释映射
        perform_comment_map = {}
        for line in lines:
            perform_match = re.search(r'PERFORM\s+(\S+)', line, re.IGNORECASE)
            if perform_match:
                pname = perform_match.group(1).upper().rstrip('.')
                comment_match = re.search(r'\"(.+?)$', line)
                if comment_match:
                    pc = comment_match.group(1).strip()
                    pc = re.sub(r'["\']*add---.*$', '', pc).strip()
                    pc = re.sub(r'["\']*modified\s*in.*$', '', pc, flags=re.IGNORECASE).strip()
                    pc = re.sub(r'^["\']+', '', pc)
                    pc = re.sub(r'["\']+$', '', pc)
                    # 去掉 "开始--"/"结束--" 等修改记录残留
                    pc = re.sub(r'^开始[-—]+.*$', '', pc).strip()
                    pc = re.sub(r'^结束[-—]+.*$', '', pc).strip()
                    if pc and len(pc) > 1:
                        perform_comment_map[pname] = pc

        if case_modules:
            seen_modules = set()  # 去重
            for cm in case_modules:
                when_val = cm['name']
                context = cm['context']
                context_comments = cm.get('context_comments', [])
                perform_names = cm.get('perform_names', [])
                cm_comment = cm.get('comment', '')

                # 过滤掉 AT SELECTION-SCREEN 残留的 WHEN 块
                if re.search(r"""['\"]""", when_val) and len(perform_names) == 0:
                    continue

                # 过滤 OTHERS
                if when_val.strip().upper() == 'OTHERS':
                    continue

                # 去重（CASE WHEN r_a OR r_b 会产生两条相同记录）
                when_key = when_val.upper().split()[0].rstrip('.') if when_val else ""
                if when_key in seen_modules:
                    continue
                seen_modules.add(when_key)

                # ---- 策略1: 直接使用 WHEN 行尾注释 ----
                business_desc = ""

                # 尝试从 PARAMETERS 注释映射获取业务描述
                if when_key in param_comment_map:
                    business_desc = param_comment_map[when_key]

                # 如果 WHEN 行本身有注释
                if not business_desc and cm_comment:
                    business_desc = cm_comment

                # 清理修改记录
                if business_desc:
                    business_desc = re.sub(r'["\']*add---.*$', '', business_desc).strip()
                    business_desc = re.sub(r'["\']*modified\s*in.*$', '', business_desc, flags=re.IGNORECASE).strip()
                    business_desc = re.sub(r'^["\']+', '', business_desc)
                    business_desc = re.sub(r'["\']+$', '', business_desc)

                # ---- 策略2: 从 PERFORM 调用的行尾注释组装业务描述 ----
                if not business_desc and perform_names:
                    perform_descs = []
                    for pn in perform_names[:5]:
                        if pn in perform_comment_map:
                            pc = perform_comment_map[pn]
                            # 去掉修改记录和无意义内容
                            pc = re.sub(r'["\']*add---.*$', '', pc).strip()
                            pc = re.sub(r'["\']*modified\s*in.*$', '', pc, flags=re.IGNORECASE).strip()
                            pc = re.sub(r'^["\']+', '', pc)
                            pc = re.sub(r'["\']+$', '', pc)
                            # 去掉以"开始"、"结束"开头的修改记录残留
                            pc = re.sub(r'^开始-{1,2}.*$', '', pc).strip()
                            pc = re.sub(r'^结束-{1,2}.*$', '', pc).strip()
                            if pc and len(pc) > 1 and pc not in perform_descs:
                                perform_descs.append(pc)
                    if perform_descs:
                        business_desc = '、'.join(perform_descs)

                # ---- 策略3: 从上下文行注释提取 ----
                if not business_desc and context_comments:
                    clean_comments = []
                    for cc in context_comments:
                        cc = re.sub(r'["\']*add---.*$', '', cc).strip()
                        cc = re.sub(r'["\']*modified\s*in.*$', '', cc, flags=re.IGNORECASE).strip()
                        if cc and cc not in clean_comments and len(cc) > 2:
                            clean_comments.append(cc)
                    if clean_comments:
                        business_desc = '、'.join(clean_comments[:3])

                # ---- 策略4: 从子程序名推断业务含义 ----
                if not business_desc and perform_names:
                    purpose_parts = []
                    for pn in perform_names[:4]:
                        purpose = self._infer_form_purpose_from_name(pn)
                        if purpose:
                            purpose_parts.append(purpose)
                    if purpose_parts:
                        business_desc = '、'.join(purpose_parts)

                # ---- 策略5: 从代码操作模式推断 ----
                if not business_desc:
                    context_upper = context.upper()
                    action_parts = []
                    if 'SELECT' in context_upper:
                        action_parts.append("查询数据")
                    if 'MODIFY' in context_upper or 'INSERT' in context_upper:
                        action_parts.append("新增/修改数据")
                    if 'DELETE' in context_upper:
                        action_parts.append("删除数据")
                    if 'CALL SCREEN' in context_upper:
                        screen_match = re.search(r'CALL\s+SCREEN\s+(\d+)', context, re.IGNORECASE)
                        screen_no = screen_match.group(1) if screen_match else ""
                        action_parts.append(f"弹出操作界面（屏幕{screen_no}）")
                    if 'COMMIT' in context_upper:
                        action_parts.append("提交数据库更改")
                    business_desc = '，'.join(action_parts) if action_parts else "功能处理"

                # 组装最终模块描述
                module_label = self._build_module_label(when_val, param_comment_map)
                module_desc = f"模块 {module_label}: {business_desc}"
                modules.append(module_desc)

        # 补充基于子程序名的功能分析（当没有 CASE 分支时）
        elif form_analysis:
            for fa in form_analysis:
                modules.append(f"子程序 {fa['name']}: {fa['purpose']}")

        return modules

    def _build_module_label(self, when_val: str, param_comment_map: Dict[str, str]) -> str:
        """构建模块标签，优先用业务名称替代技术变量名

        例如: r_zccrt1 → "创建暂存发票"（如果 PARAMETERS 注释中有）
              r_vf_crt  → "创建或冲销SAP发票"
        """
        when_key = when_val.upper().split()[0].rstrip('.') if when_val else ""
        if when_key in param_comment_map:
            desc = param_comment_map[when_key]
            # 清理修改记录
            desc = re.sub(r'["\']*add---.*$', '', desc).strip()
            desc = re.sub(r'["\']*modified\s*in.*$', '', desc, flags=re.IGNORECASE).strip()
            # 去掉开头引号
            desc = re.sub(r'^["\']+', '', desc)
            if desc:
                return f"{when_key}（{desc}）"
        return when_val

    def _infer_form_purpose_from_name(self, form_name: str) -> str:
        """从子程序名称推断业务目的（用业务语言描述）

        常见前缀/关键词 → 业务含义映射
        """
        fn = form_name.upper().rstrip('.')

        # 特殊映射表（按匹配优先级排列）
        special_mappings = [
            (r'LOCK', '锁定数据防止并发修改'),
            (r'UNLOCK', '解锁数据'),
            (r'GET_JDX_DATA', '获取借贷项数据'),
            (r'GET_DISPLAY_DATA', '获取待显示数据'),
            (r'GET_DATA', '获取业务数据'),
            (r'GET_TO_POST_DATA', '获取待过账数据'),
            (r'GET_VF_DATA', '获取SAP发票数据'),
            (r'PROCESS_DATA', '汇总加工业务数据'),
            (r'SPLIT_S_VGBEL', '将销售订单号分段批量处理'),
            (r'DUPLICATE_RANGE', '选择条件去重'),
            (r'INIT_DATE', '初始化日期默认值'),
            (r'SET_SCREEN_OUTPUT', '设置屏幕显示属性'),
            (r'SET_CONDITIONS', '设置查询条件'),
            (r'AUTHORITY_CHECK', '检查用户操作权限'),
            (r'ESY_CANCEL', '撤回E税云发票'),
            (r'300_GET_DATA', '查询暂存发票明细'),
            (r'QUERY', '查询数据'),
        ]

        for pattern, meaning in special_mappings:
            if re.search(pattern, fn):
                return meaning

        # 通用前缀映射
        prefix_mappings = [
            (r'^FRM_', ''),  # 去掉 ABAP 常见的 FRM_ 前缀
        ]
        clean_name = fn
        for pattern, replacement in prefix_mappings:
            clean_name = re.sub(pattern, replacement, clean_name)

        # 通用前缀推断
        prefix_meanings = [
            (r'^CREATE|^CRE|^ADD|^NEW', '创建'),
            (r'^DELETE|^DEL|^REMOVE|^CANCEL', '删除'),
            (r'^UPDATE|^MOD|^MODIFY|^CHG|^CHANGE', '修改'),
            (r'^GET|^READ|^FETCH|^SEL|^SELECT|^FIND', '查询'),
            (r'^DISPLAY|^SHOW|^VIEW|^LIST|^PRINT', '展示'),
            (r'^CHECK|^VALIDATE|^VERIFY', '校验'),
            (r'^PROCESS|^PROC|^RUN|^EXEC', '处理'),
            (r'^CALC|^COMPUTE|^SUM|^TOTAL', '计算'),
            (r'^EXPORT|^DOWNLOAD', '导出'),
            (r'^IMPORT|^UPLOAD|^LOAD', '导入'),
            (r'^REVERS|^ROLLBACK|^UNDO', '冲销'),
            (r'^APPROV|^AUTH', '审批'),
            (r'^ALLOCAT|^ASSIGN|^DISTRIBUTE', '分配'),
        ]

        for pattern, meaning in prefix_meanings:
            if re.search(pattern, clean_name):
                # 尝试从名称中提取额外业务信息
                remaining = re.sub(pattern, '', clean_name)
                remaining = re.sub(r'_', '', remaining)
                if remaining:
                    return f"{meaning}{remaining}相关数据"
                return f"{meaning}数据"

        return ""
    
    def _build_technical_features(self, lines: List[str], function_refs: List[str],
                                   events_found: List[str],
                                   interaction_features: Dict) -> str:
        """组装技术特征总结"""
        features = []
        
        # 程序架构
        if interaction_features.get('selection_blocks'):
            features.append(f"选择屏幕包含 {len(interaction_features['selection_blocks'])} 个区块")
        
        # 事件驱动
        if events_found:
            features.append(f"使用 {'、'.join(events_found[:3])}")
        
        # 数据一致性
        if interaction_features.get('enqueue_funcs'):
            features.append(f"使用 SAP 锁机制（{', '.join(interaction_features['enqueue_funcs'][:2])}）保证数据一致性")
        
        # 权限控制
        if interaction_features.get('auth_objects'):
            features.append(f"权限校验: {'、'.join(interaction_features['auth_objects'][:3])}")
        
        # ALV
        if interaction_features.get('has_alv'):
            features.append("使用 ALV 报表展示")
        
        # BDC
        if interaction_features.get('has_bdc'):
            features.append("使用 BDC/Call Transaction 批处理")
        
        # 事务完整性
        has_commit = any(re.search(r'\bCOMMIT\s+WORK\b', l, re.IGNORECASE) for l in lines)
        has_rollback = any(re.search(r'\bROLLBACK\s+WORK\b', l, re.IGNORECASE) for l in lines)
        if has_commit and has_rollback:
            features.append("事务控制: COMMIT WORK / ROLLBACK WORK")
        elif has_commit:
            features.append("事务控制: COMMIT WORK")
        
        # 异常处理
        has_try = any(re.search(r'\bTRY\b', l, re.IGNORECASE) for l in lines)
        if has_try:
            features.append("使用 TRY/CATCH 异常处理")
        
        return '；'.join(features) if features else "标准ABAP程序结构"

    def analyze_directory(self, abap_files, dir_path: str,
                          user_hints: List[str] = None) -> AnalysisReport:
        """分析目录下多个ABAP文件（主程序 + INCLUDE 文件）

        按主程序中 INCLUDE 顺序依次分析各文件，生成合并报告。

        Args:
            abap_files: ABAP文件列表
            dir_path: 目录路径
            user_hints: 用户提供的提示信息列表

        Returns:
            AnalysisReport: 目录模式分析报告
        """
        from frm_bae_file_handler import FileHandler

        dir_path_obj = Path(dir_path)
        fh = FileHandler()

        # 1) 生成目录树
        directory_tree = fh.get_directory_tree(dir_path_obj)

        # 2) 识别主程序
        main_file = fh.detect_main_program(abap_files, dir_path_obj)
        if not main_file:
            # 退化为单文件分析模式
            if len(abap_files) == 1:
                return self.analyze(abap_files[0], user_hints=user_hints)
            raise ValueError("无法识别主程序，请确认目录中包含 REPORT/PROGRAM 声明的文件")

        main_name = main_file.file_name
        print(f"  📌 识别主程序: {main_name}")

        # 2b) 识别程序池（Program Pool：INCLUDE 所有其他文件的文件）
        pool_file = fh.detect_program_pool(abap_files)
        pool_name = pool_file.file_name if pool_file else main_name
        if pool_file and pool_file.file_name != main_name:
            print(f"  📋 识别程序池: {pool_name}（与主程序不同）")
        elif pool_file:
            print(f"  📋 识别程序池: {pool_name}（与主程序相同）")

        # 3) 解析 INCLUDE 顺序（优先从程序池解析，其次从主程序解析）
        if pool_file:
            include_order = fh.get_include_order(pool_file, abap_files)
        else:
            include_order = fh.get_include_order(main_file, abap_files)
        # 按顺序排序所有文件
        sorted_files = sorted(
            abap_files,
            key=lambda f: include_order.get(f.file_name.lower(), 9999)
        )

        # 4) 按顺序逐个分析
        file_results: List[FileAnalysisResult] = []
        all_annotations = []
        all_table_refs = []
        all_function_refs = []
        all_program_refs = []
        total_lines = 0
        overall_logic_parts = []
        include_labels = []

        for idx, abap_file in enumerate(sorted_files):
            order_num = include_order.get(abap_file.file_name.lower(), 9999)
            is_main = (abap_file.file_name == main_name)

            label = "主程序" if is_main else f"INCLUDE #{order_num}"
            if is_main:
                print(f"  📄 [{label}] {abap_file.file_name} ({abap_file.source_type}, {len(abap_file.content.split(chr(10)))}行)")
            else:
                print(f"  📄 [{label}] {abap_file.file_name} ({abap_file.source_type}, {len(abap_file.content.split(chr(10)))}行)")

            include_labels.append(f"{label}: {abap_file.file_name}")

            # 对每个文件执行完整的 analyze
            single_report = self.analyze(abap_file, user_hints=user_hints or [])

            # 行号偏移：累加前面文件的行数
            line_offset = total_lines

            # 构建 FileAnalysisResult
            far = FileAnalysisResult(
                file_name=abap_file.file_name,
                file_path=abap_file.file_path,
                source_type=abap_file.source_type,
                total_lines=single_report.total_lines,
                annotations=single_report.annotations,
                overall_logic=single_report.overall_logic,
                block_summary=single_report.block_summary,
                table_refs=single_report.table_refs,
                function_refs=single_report.function_refs,
                program_refs=single_report.program_refs,
                business_analysis=single_report.business_analysis,
                include_order=order_num,
            )
            file_results.append(far)

            # 合并 annotations（调整行号偏移）
            for ann in single_report.annotations:
                ann.line_number += line_offset
                all_annotations.append(ann)

            # 合并引用（去重）
            for t in single_report.table_refs:
                if t not in all_table_refs:
                    all_table_refs.append(t)
            for f in single_report.function_refs:
                if f not in all_function_refs:
                    all_function_refs.append(f)
            for p in single_report.program_refs:
                if p not in all_program_refs:
                    all_program_refs.append(p)

            total_lines += single_report.total_lines

            # 整体逻辑部分：只在主程序的分析结果中使用
            if is_main:
                overall_logic_parts.append(single_report.overall_logic)

        # 5) 如果有未在 INCLUDE 顺序中的文件，追加说明
        included_names = set(include_order.keys())
        missed = [f for f in abap_files if f.file_name.lower() not in included_names]
        if missed:
            overall_logic_parts.append("")
            overall_logic_parts.append("【其他未在主程序 INCLUDE 中引用的文件】")
            for f in missed:
                overall_logic_parts.append(f"  - {f.file_name} ({f.source_type})")

        # 6) 构建合并的 overall_logic
        overall_logic_text = '\n'.join(overall_logic_parts)

        # 7) 生成深度分析（基于主程序）
        business_analysis = None
        main_result = next((r for r in file_results if r.include_order == 0), None)
        if main_result and main_result.business_analysis:
            business_analysis = main_result.business_analysis

        return AnalysisReport(
            file_name=dir_path_obj.name,
            file_path=str(dir_path_obj.resolve()),
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            total_lines=total_lines,
            source_type="DIRECTORY",
            annotations=all_annotations,
            overall_logic=overall_logic_text,
            block_summary={},  # 目录模式不生成合并的块统计
            table_refs=all_table_refs,
            function_refs=all_function_refs,
            program_refs=all_program_refs,
            user_hints=user_hints or [],
            business_analysis=business_analysis,
            directory_mode=True,
            directory_tree=directory_tree,
            main_program=main_name,
            program_pool=pool_name,
            file_results=file_results,
        )
